import 'package:flutter/material.dart';
class BottomNavButton extends StatelessWidget {
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const BottomNavButton({
    Key? key,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.translucent,
      child: Container(
        padding: const EdgeInsets.all(12.0), // Tăng vùng ấn
        decoration: isSelected
            ? BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Colors.green.withOpacity(0.1),
        )
            : null,
        child: Icon(
          icon,
          color: isSelected ? Colors.green : Colors.grey,
          size: isSelected ? 32 : 28,
        ),
      ),
    );
  }
}