import 'package:flutter/material.dart';
import 'package:doan_monhoc/service/icon_service.dart';

class IconPickerDialog extends StatelessWidget {
  const IconPickerDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("Chọn biểu tượng"),
      content: SizedBox(
        height: 300, // Giới hạn chiều cao của hộp thoại
        width: double.maxFinite,
        child: Scrollbar(
          // Thêm thanh trượt
          thumbVisibility: true, // Luôn hiển thị thanh trượt
          child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4, // Số cột trong grid
              crossAxisSpacing: 8.0,
              mainAxisSpacing: 8.0,
              childAspectRatio: 1, // Tỉ lệ chiều rộng và chiều cao của mỗi ô
            ),
            itemCount: IconService.getIcons().length,
            itemBuilder: (context, index) {
              final iconData = IconService.getIcons()[index]["icon"];
              final iconUnicode = IconService.getIcons()[index]["unicode"];
              return IconButton(
                icon: Icon(iconData),
                onPressed: () {
                  // Trả về cả IconData và mã Unicode
                  Navigator.pop(context, {
                    "iconData": iconData,
                    "iconUnicode": iconUnicode,
                  });
                },
              );
            },
          ),
        ),
      ),
    );
  }
}