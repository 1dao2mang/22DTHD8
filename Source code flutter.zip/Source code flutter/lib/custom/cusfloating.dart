import 'package:flutter/material.dart';
class CustomFloatingActionButton extends StatelessWidget {
  final int currentIndex;
  final VoidCallback onPressed;

  const CustomFloatingActionButton({
    Key? key,
    required this.currentIndex,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: onPressed,
      backgroundColor: Colors.green,
      child: Icon(
        currentIndex == 0
            ? Icons.add
            : currentIndex == 1
            ? Icons.menu
            : Icons.account_balance_wallet, // Biểu tượng khác nhau tùy thuộc vào trang
      ),
    );
  }
}