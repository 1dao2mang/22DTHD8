import 'package:flutter/material.dart';
import 'package:doan_monhoc/custom/icon_dialog.dart'; // Import IconPickerDialog
import 'package:doan_monhoc/utils/account.dart'; // Import AccountService để lấy UserID
import 'package:doan_monhoc/utils/crud_tsaction.dart'; // Import CrudTransaction để gọi API
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:doan_monhoc/screens/transaction.dart';// Import FontAwesomeIcons

class CustomTransactionDialog extends StatefulWidget {
  final String? initialName;
  final String? initialIcon;
  final int? initialType;
  final Function(String name, String iconUnicode, int type, String userId) onConfirm;
  final VoidCallback onConfirmCallback;

  const CustomTransactionDialog({
    Key? key,
    this.initialName,
    this.initialIcon,
    this.initialType,
    required this.onConfirm,
    required this.onConfirmCallback,
  }) : super(key: key);

  @override
  _CustomTransactionDialogState createState() => _CustomTransactionDialogState();
}

class _CustomTransactionDialogState extends State<CustomTransactionDialog> {
  final TextEditingController _nameController = TextEditingController();
  String _selectedCategory = 'Tiền mặt'; // Giá trị mặc định
  IconData? _selectedIconData; // IconData để hiển thị hình ảnh
  String? _selectedIconUnicode; // Mã Unicode để gửi đi khi bấm Xác nhận

  @override
  void initState() {
    super.initState();
    // Khởi tạo giá trị ban đầu từ tham số
    if (widget.initialName != null) {
      _nameController.text = widget.initialName!;
    }
    if (widget.initialIcon != null) {
      _selectedIconUnicode = widget.initialIcon!;
      _selectedIconData = IconDataSolid(int.parse('0x${widget.initialIcon!}'));
    }
    if (widget.initialType != null) {
      switch (widget.initialType) {
        case 1:
          _selectedCategory = 'Tiền mặt';
          break;
        case 2:
          _selectedCategory = 'Chi tiêu';
          break;
        case 3:
          _selectedCategory = 'Các giao dịch khác';
          break;
        default:
          _selectedCategory = 'Tiền mặt';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8,
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildTitle(),
            const SizedBox(height: 20),
            _buildNameField(),
            const SizedBox(height: 20),
            _buildCategoryDropdown(),
            const SizedBox(height: 20),
            _buildIconPicker(),
            const SizedBox(height: 20),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  // Tiêu đề
  Widget _buildTitle() {
    return const Text(
      'Thêm giao dịch mới',
      style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.blue,
      ),
    );
  }

  // Trường nhập tên
  Widget _buildNameField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Tên',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _nameController,
          decoration: InputDecoration(
            hintText: 'Nhập tên giao dịch',
            border: InputBorder.none,
            enabledBorder: const UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.grey),
            ),
            focusedBorder: const UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.blue),
            ),
          ),
          keyboardType: TextInputType.text,
          textInputAction: TextInputAction.done,
        ),
      ],
    );
  }

  // Dropdown chọn loại
  Widget _buildCategoryDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Loại',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: Colors.grey[400]!,
              width: 1,
            ),
          ),
          child: DropdownButton<String>(
            value: _selectedCategory,
            onChanged: (String? newValue) {
              setState(() {
                _selectedCategory = newValue!;
              });
            },
            items: <String>['Tiền mặt', 'Chi tiêu', 'Các giao dịch khác']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
              );
            }).toList(),
            isExpanded: true,
            underline: const SizedBox(),
            icon: const Icon(
              Icons.arrow_drop_down,
              color: Colors.blue,
            ),
            dropdownColor: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ],
    );
  }

  // Chọn biểu tượng
  Widget _buildIconPicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Biểu tượng',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _openIconPicker,
              child: const Text('Chọn Icon'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(width: 10),
            if (_selectedIconData != null)
              Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Icon(
                    _selectedIconData,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  // Nút hành động (Hủy và Xác nhận)
  Widget _buildActionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildCancelButton(),
        const SizedBox(width: 20),
        _buildConfirmButton(),
      ],
    );
  }

  // Nút Hủy
  Widget _buildCancelButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.red,
          width: 1,
        ),
      ),
      child: TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            'Hủy',
            style: TextStyle(
              fontSize: 16,
              color: Colors.red,
            ),
          ),
        ),
      ),
    );
  }

  // Nút Xác nhận
  Widget _buildConfirmButton() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.blue,
          width: 1,
        ),
      ),
      child: TextButton(
        onPressed: _onConfirm,
        child: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            'Xác Nhận',
            style: TextStyle(
              fontSize: 16,
              color: Colors.blue,
            ),
          ),
        ),
      ),
    );
  }

  // Mở hộp thoại chọn biểu tượng
  void _openIconPicker() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => const IconPickerDialog(),
    );

    if (result != null) {
      setState(() {
        _selectedIconData = result["iconData"]; // Lưu IconData để hiển thị
        _selectedIconUnicode = result["iconUnicode"]; // Lưu mã Unicode để gửi đi
      });
    }
  }

  // Xử lý khi nhấn nút Xác nhận
  // Xử lý khi nhấn nút Xác nhận
  void _onConfirm() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng nhập tên giao dịch')),
      );
      return;
    }

    if (_selectedIconUnicode == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng chọn biểu tượng')),
      );
      return;
    }

    // Lấy UserID từ SharedPreferences
    final userData = await AccountService.getUserData();
    final userId = userData['id'];

    if (userId == null || userId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Không tìm thấy thông tin người dùng. Vui lòng đăng nhập lại!')),
      );
      return;
    }

    // Chuyển đổi loại giao dịch thành giá trị số (1, 2, hoặc 3)
    int type;
    switch (_selectedCategory) {
      case 'Tiền mặt':
        type = 1;
        break;
      case 'Chi tiêu':
        type = 2;
        break;
      case 'Các giao dịch khác':
        type = 3;
        break;
      default:
        type = 1; // Mặc định là Tiền mặt
    }

    try {
      // Gọi callback với dữ liệu đã nhập
      final newTransaction = await widget.onConfirm(
        _nameController.text,
        _selectedIconUnicode!,
        type,
        userId,
      );

      // Hiển thị thông báo thành công
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Thêm giao dịch thành công')),
      );

      // Gọi callback để thông báo rằng việc xác nhận đã hoàn tất
      widget.onConfirmCallback();

      // Đóng dialog và trả về giao dịch mới
      if (mounted) {
        Navigator.pop(context, newTransaction); // Trả về giao dịch mới
      }
    } catch (e) {
      print('Lỗi khi thêm giao dịch: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Thêm giao dịch thất bại')),
      );

      // Đóng dialog và trả về null nếu có lỗi
      if (mounted) {
        Navigator.pop(context, null);
      }
    }
  }
}