import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class IconService {
  // Danh sách các icon với mã Unicode tương ứng
  static final List<Map<String, dynamic>> icons = [
    {"icon": FontAwesomeIcons.moneyBill, "unicode": "f0d6 "},
    {"icon": FontAwesomeIcons.creditCard, "unicode": "f09d"},
    {"icon": FontAwesomeIcons.wallet, "unicode": "f555"},
    {"icon": FontAwesomeIcons.piggyBank, "unicode": "f4d3"},
    {"icon": FontAwesomeIcons.coins, "unicode": "f51e"},
    {"icon": FontAwesomeIcons.gem, "unicode": "f3a5"},
    {"icon": FontAwesomeIcons.diamond, "unicode": "f219"},
    {"icon": FontAwesomeIcons.calculator, "unicode": "f1ec"},
    {"icon": FontAwesomeIcons.moneyBillWave, "unicode": "f53a"},
    {"icon": FontAwesomeIcons.moneyCheckDollar, "unicode": "f53d"},
    {"icon": FontAwesomeIcons.cartShopping, "unicode": "f07a"},
    {"icon": FontAwesomeIcons.bagShopping, "unicode": "f290"},
    {"icon": FontAwesomeIcons.basketShopping, "unicode": "f291"},
    {"icon": FontAwesomeIcons.tag, "unicode": "f02b"},
    {"icon": FontAwesomeIcons.receipt, "unicode": "f543"},
    {"icon": FontAwesomeIcons.fileInvoice, "unicode": "f570"},
    {"icon": FontAwesomeIcons.fileInvoiceDollar, "unicode": "f571"},
    {"icon": FontAwesomeIcons.handHoldingDollar, "unicode": "f4c0"},
    {"icon": FontAwesomeIcons.briefcase, "unicode": "f0b1"},
    {"icon": FontAwesomeIcons.building, "unicode": "f1ad"},
    {"icon": FontAwesomeIcons.landmark, "unicode": "f66f"},
    {"icon": FontAwesomeIcons.house, "unicode": "f015"},
    {"icon": FontAwesomeIcons.hotel, "unicode": "f594"},
    {"icon": FontAwesomeIcons.bed, "unicode": "f236"},
    {"icon": FontAwesomeIcons.utensils, "unicode": "f2e7"},
    {"icon": FontAwesomeIcons.champagneGlasses, "unicode": "f79f"},
    {"icon": FontAwesomeIcons.beerMugEmpty, "unicode": "f0fc"},
    {"icon": FontAwesomeIcons.wineGlass, "unicode": "f4e3"},
    {"icon": FontAwesomeIcons.mugSaucer, "unicode": "f0f4"},
    {"icon": FontAwesomeIcons.iceCream, "unicode": "f810"},
    {"icon": FontAwesomeIcons.gift, "unicode": "f06b"},
    {"icon": FontAwesomeIcons.truckFast, "unicode": "f48b"},
    {"icon": FontAwesomeIcons.plane, "unicode": "f072"},
    {"icon": FontAwesomeIcons.car, "unicode": "f1b9"},
    {"icon": FontAwesomeIcons.bicycle, "unicode": "f206"},
    {"icon": FontAwesomeIcons.bus, "unicode": "f207"},
    {"icon": FontAwesomeIcons.train, "unicode": "f238"},
    {"icon": FontAwesomeIcons.ship, "unicode": "f21a"},
    {"icon": FontAwesomeIcons.motorcycle, "unicode": "f21c"},
    {"icon": FontAwesomeIcons.gasPump, "unicode": "f52f"},
    {"icon": FontAwesomeIcons.question, "unicode": "f128"},
  ];

  // Lấy danh sách các icon
  static List<Map<String, dynamic>> getIcons() {
    return icons;
  }
}