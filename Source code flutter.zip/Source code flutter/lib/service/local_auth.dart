import 'package:local_auth/local_auth.dart';
import 'package:flutter/services.dart';

enum SupportState {
  unknown,
  supported,
  unSupported,
}

class LocalAuth {
  final LocalAuthentication _auth = LocalAuthentication();
  SupportState _supportState = SupportState.unknown;
  List<BiometricType>? _availableBiometrics;

  SupportState get supportState => _supportState;
  List<BiometricType>? get availableBiometrics => _availableBiometrics;

  Future<void> checkBiometricSupport() async {
    try {
      final bool isSupported = await _auth.isDeviceSupported();
      _supportState = isSupported ? SupportState.supported : SupportState.unSupported;
    } on PlatformException catch (e) {
      print(e);
      _supportState = SupportState.unSupported;
    }
  }

  Future<List<BiometricType>> getAvailableBiometrics() async {
    try {
      _availableBiometrics = await _auth.getAvailableBiometrics();
      print("Supported biometrics: $_availableBiometrics");
      return _availableBiometrics!;
    } on PlatformException catch (e) {
      print(e);
      _availableBiometrics = [];
      return [];
    }
  }

  Future<bool> authenticateWithBiometrics() async {
    try {
      final bool authenticated = await _auth.authenticate(
        localizedReason: 'Authenticate with fingerprint or Face ID',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );
      return authenticated;
    } on PlatformException catch (e) {
      print(e);
      return false;
    }
  }
}