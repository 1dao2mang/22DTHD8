import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart'; // Import Font Awesome Icons

class ExpenseCategory {
  final String id;
  String name;
  int type;
  String icon; // Thay đổi từ int sang String để lưu mã Unicode
  final String userId;
  final dynamic user;
  final List<dynamic> transactions;

  ExpenseCategory({
    required this.id,
    required this.name,
    required this.type,
    required this.icon, // Kiểu dữ liệu là String
    required this.userId,
    this.user,
    this.transactions = const [],
  });

  factory ExpenseCategory.fromJson(Map<String, dynamic> json) {
    return ExpenseCategory(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      type: json['type'] ?? 0,
      icon: json['icon'] ?? 'f067', // Giá trị mặc định nếu `icon` là null
      userId: json['userId'] ?? '',
      user: json['user'],
      transactions: json['transactions'] ?? [],
    );
  }
}

class TransactionItem extends StatelessWidget {
  final ExpenseCategory transaction;

  const TransactionItem({required this.transaction});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.green.withOpacity(0.2),
        child: Icon(
          IconData(
            int.parse('0x${transaction.icon}', radix: 16), // Chuyển đổi mã Unicode sang số nguyên
            fontFamily: 'FontAwesome', // Đúng fontFamily
          ),
          color: Colors.green,
        ),
      ),
      title: Text(
        transaction.name,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
    );
  }
}