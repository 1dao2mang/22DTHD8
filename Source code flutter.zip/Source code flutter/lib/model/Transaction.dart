import 'package:intl/intl.dart';

class Transaction {
  String id;
  String userId;
  String expenseCategoryId;
  double amount;
  DateTime date; // Giữ nguyên kiểu DateTime
  String description;
  int? expenseCategoryType;
  String? expenseCategoryIcon;

  Transaction({
    required this.id,
    required this.userId,
    required this.expenseCategoryId,
    required this.amount,
    required this.date, // Kiểu dữ liệu là DateTime
    required this.description,
    this.expenseCategoryType,
    this.expenseCategoryIcon,
  });

  // Phương thức fromJson để chuyển đổi JSON thành đối tượng Transaction
  factory Transaction.fromJson(Map<String, dynamic> json) {
    DateTime date;
    try {
      // Kiểm tra nếu json['date'] là null hoặc rỗng
      if (json['date'] == null || json['date'].isEmpty) {
        date = DateTime.now(); // Sử dụng giá trị mặc định
      } else {
        // Chuyển đổi chuỗi ISO 8601 sang DateTime
        date = DateTime.parse(json['date']);
      }
    } catch (e) {
      print('Lỗi khi chuyển đổi ngày tháng: $e');
      date = DateTime.now(); // Sử dụng giá trị mặc định nếu có lỗi
    }

    return Transaction(
      id: json['id'],
      userId: json['userId'],
      expenseCategoryId: json['expenseCategoryId'],
      amount: json['amount'],
      date: date, // Sử dụng giá trị date đã chuyển đổi
      description: json['description'],
      expenseCategoryType: json['expenseCategoryType'],
      expenseCategoryIcon: json['expenseCategoryIcon'],
    );
  }
}