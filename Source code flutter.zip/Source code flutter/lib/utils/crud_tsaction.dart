  import 'dart:convert';
  import 'package:http/http.dart' as http;
  import 'package:flutter_dotenv/flutter_dotenv.dart';
  import 'package:doan_monhoc/model/ExpenseCategory.dart'; // Import model mới

  class CrudTransaction {
    // Thêm các loại giao dịch mặc định theo UserId
    static Future<void> addDefaultExpenseCategories(String userId) async {
      final response = await http.post(
        Uri.parse('${dotenv.env['BASE_URL']}ExpenseCategory/AddDefaultCategories/$userId'),
      );

      if (response.statusCode != 200 && response.statusCode != 201) {
        throw Exception('Failed to add default expense categories');
      }
    }

    // Lấy danh sách loại giao dịch theo UserId
    static Future<List<ExpenseCategory>> getExpenseCategoriesByUserId(String userId) async {
      final response = await http.get(
        Uri.parse('${dotenv.env['BASE_URL']}ExpenseCategory/ByUser/$userId'),
      );

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        if (data != null) {
          return data.map((e) => ExpenseCategory.fromJson(e)).toList();
        } else {
          throw Exception('No data found');
        }
      } else {
        throw Exception('Failed to load expense categories');
      }
    }



    // Thêm mới một loại giao dịch
    static Future<void> addExpenseCategory({
      required String userId,
      required String name,
      required int type,
      required String icon,
    }) async {
      final response = await http.post(
        Uri.parse('${dotenv.env['BASE_URL']}ExpenseCategory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'userId': userId,
          'name': name,
          'type': type,
          'icon': icon,
        }),
      );

      if (response.statusCode != 200 && response.statusCode != 201) {
        throw Exception('Failed to add expense category');
      }
    }

    // Cập nhật một loại giao dịch
    static Future<void> updateExpenseCategory({
      required String id,
      required String userId,
      required String name,
      required int type,
      required String icon,
    }) async {
      final response = await http.put(
        Uri.parse('${dotenv.env['BASE_URL']}ExpenseCategory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'id': id,
          'userId': userId,
          'name': name,
          'type': type,
          'icon': icon,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to update expense category');
      }
    }

    // Xóa một loại giao dịch
    static Future<void> deleteExpenseCategory({
      required String id,
      required String userId,
    }) async {
      final response = await http.delete(
        Uri.parse('${dotenv.env['BASE_URL']}ExpenseCategory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'id': id,
          'userId': userId,
        }),
      );

      if (response.statusCode != 204) {
        throw Exception('Failed to delete expense category');
      }
    }
  }

