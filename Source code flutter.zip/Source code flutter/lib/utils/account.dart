import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doan_monhoc/config/config_url.dart'; // Import class ConfigURL để sử dụng BASE_URL từ file .env

class AccountService {
  // Endpoints
  static const String LOGIN_ENDPOINT = "Auth/login";
  static const String REGISTER_ENDPOINT = "Auth/register";
  static const String UPDATE_AVATAR_ENDPOINT = "auth/update-avatar";
  static const String SEND_VERIFICATION_EMAIL_ENDPOINT = "auth/send-verification-email";
  static const String VERIFY_EMAIL_ENDPOINT = "auth/verify-email";

  // SharedPreferences keys
  static const String USER_ID_KEY = 'id';
  static const String USER_FULL_NAME_KEY = 'fullName';
  static const String USER_EMAIL_KEY = 'email';
  static const String USER_AVATAR_URL_KEY = 'avatarUrl';

  // ImgBB API key
  static const String IMGBB_API_KEY = 'd509d652e59f0bbaccec291b4ea880e6';
  static const String IMGBB_UPLOAD_URL = 'https://api.imgbb.com/1/upload';

  // Hàm đăng nhập
  static Future<Map<String, dynamic>> login(String email, String password) async {
    final String url = ConfigURL.baseUrl + LOGIN_ENDPOINT;

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('API Response: $data'); // Debug: In ra phản hồi từ API

        // Lưu thông tin người dùng nếu có
        if (data['data'] != null) {
          await _saveUserData(data['data']); // Lưu thông tin từ trường 'data'
        }

        return {"success": true, "data": data['data']}; // Trả về thông tin từ trường 'data'
      } else if (response.statusCode == 401) {
        return {"success": false, "message": "Email hoặc mật khẩu không chính xác."};
      } else {
        return {"success": false, "message": jsonDecode(response.body)['message'] ?? "Đăng nhập thất bại"};
      }
    } catch (error) {
      return {"success": false, "message": "Không thể kết nối đến máy chủ. Vui lòng thử lại!"};
    }
  }

  // Hàm đăng ký
  static Future<Map<String, dynamic>> register(String fullName, String email, String password) async {
    final String url = ConfigURL.baseUrl + REGISTER_ENDPOINT;

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'fullName': fullName, 'email': email, 'password': password}),
      );

      if (response.statusCode == 200) {
        return {"success": true, "data": jsonDecode(response.body)};
      } else if (response.statusCode == 409) {
        return {"success": false, "message": "Email đã được sử dụng."};
      } else {
        return {"success": false, "message": jsonDecode(response.body)['message'] ?? "Đăng ký thất bại"};
      }
    } catch (error) {
      return {"success": false, "message": "Không thể kết nối đến máy chủ. Vui lòng thử lại!"};
    }
  }

  // Hàm gửi yêu cầu xác thực email
  static Future<Map<String, dynamic>> sendVerificationEmail(String email) async {
    final String url = ConfigURL.baseUrl + SEND_VERIFICATION_EMAIL_ENDPOINT;

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email}),
      );

      if (response.statusCode == 200) {
        return {"success": true, "message": "Email xác thực đã được gửi."};
      } else {
        return {"success": false, "message": jsonDecode(response.body)['message'] ?? "Gửi email xác thực thất bại"};
      }
    } catch (error) {
      return {"success": false, "message": "Không thể kết nối đến máy chủ. Vui lòng thử lại!"};
    }
  }

  // Hàm xác nhận email bằng token
  static Future<Map<String, dynamic>> verifyEmail(String token) async {
    final String url = '${ConfigURL.baseUrl}Auth/verify-email?token=$token'; // Thêm token vào query parameter

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {'accept': '*/*'}, // Thêm header 'accept'
      );

      if (response.statusCode == 200) {
        return {"success": true, "message": "Email đã được xác thực thành công."};
      } else {
        return {"success": false, "message": jsonDecode(response.body)['message'] ?? "Xác thực email thất bại"};
      }
    } catch (error) {
      return {"success": false, "message": "Không thể kết nối đến máy chủ. Vui lòng thử lại!"};
    }
  }

  // Hàm tải ảnh lên ImgBB
  static Future<String> uploadImageToServer(File image) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse(IMGBB_UPLOAD_URL));
      request.fields['key'] = IMGBB_API_KEY;
      request.files.add(await http.MultipartFile.fromPath('image', image.path));

      final response = await request.send();

      if (response.statusCode == 200) {
        final responseData = await response.stream.bytesToString();
        final jsonResponse = jsonDecode(responseData);
        return jsonResponse['data']['url']; // Trả về URL của ảnh
      } else {
        final errorResponse = await response.stream.bytesToString();
        throw Exception('Failed to upload image. Status code: ${response.statusCode}, Response: $errorResponse');
      }
    } catch (e) {
      throw Exception('Lỗi khi tải ảnh lên ImgBB: $e');
    }
  }

  // Hàm cập nhật URL ảnh đại diện
  static Future<String> updateAvatarUrl(String userId, String avatarUrl) async {
    final String url = ConfigURL.baseUrl + UPDATE_AVATAR_ENDPOINT;

    final response = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'userId': userId, 'avatarUrl': avatarUrl}),
    );

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      return jsonResponse['avatarUrl']; // Trả về URL avatar mới
    } else {
      throw Exception('Failed to update avatar');
    }
  }

  // Hàm tải ảnh lên và cập nhật URL ảnh đại diện
  static Future<String> uploadAndUpdateAvatar(File image, String userId) async {
    try {
      // Tải ảnh lên ImgBB
      String avatarUrl = await uploadImageToServer(image);

      // Cập nhật URL ảnh đại diện
      String newAvatarUrl = await updateAvatarUrl(userId, avatarUrl);

      // Lưu URL mới vào SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(USER_AVATAR_URL_KEY, newAvatarUrl);

      return newAvatarUrl;
    } catch (e) {
      throw Exception('Lỗi khi tải lên và cập nhật avatar: $e');
    }
  }

  // Hàm lưu thông tin người dùng vào SharedPreferences
  static Future<void> _saveUserData(Map<String, dynamic> userData) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(USER_ID_KEY, userData['id']);
    await prefs.setString(USER_FULL_NAME_KEY, userData['fullName']);
    await prefs.setString(USER_EMAIL_KEY, userData['email']);
    await prefs.setString(
      USER_AVATAR_URL_KEY,
      userData['avatarUrl'] ?? 'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl.jpg',
    );
  }

  // Hàm lấy thông tin người dùng từ SharedPreferences
  static Future<Map<String, String>> getUserData() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      USER_ID_KEY: prefs.getString(USER_ID_KEY) ?? '',
      USER_FULL_NAME_KEY: prefs.getString(USER_FULL_NAME_KEY) ?? '',
      USER_EMAIL_KEY: prefs.getString(USER_EMAIL_KEY) ?? '',
      USER_AVATAR_URL_KEY: prefs.getString(USER_AVATAR_URL_KEY) ??
          'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl.jpg',
    };
  }

  // Hàm đăng xuất (Xóa thông tin người dùng)
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // Xóa tất cả thông tin đã lưu
  }
}