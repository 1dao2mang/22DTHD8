import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class CustomChart extends StatelessWidget {
  final String title;
  final double totalBudget;
  final double remainingBudget;
  final Color rangeColor;
  final Color axisColor;
  final double thickness;
  final String period;

  const CustomChart({
    Key? key,
    required this.title,
    required this.totalBudget,
    required this.remainingBudget,
    required this.rangeColor,
    required this.axisColor,
    this.thickness = 13,
    required this.period,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.8,
            height: MediaQuery.of(context).size.width * 0.8,
            child: SfRadialGauge(
              axes: <RadialAxis>[
                RadialAxis(
                  startAngle: 180,
                  endAngle: 0,
                  minimum: 0,
                  maximum: totalBudget,
                  showLabels: false,
                  showTicks: false,
                  axisLineStyle: AxisLineStyle(
                    thickness: 13,
                    cornerStyle: CornerStyle.bothCurve,
                    color: axisColor,
                  ),
                  pointers: <GaugePointer>[
                    RangePointer(
                      value: remainingBudget,
                      width: 13,
                      cornerStyle: CornerStyle.bothCurve,
                      color: rangeColor,
                    ),
                  ],
                  annotations: <GaugeAnnotation>[
                    GaugeAnnotation(
                      widget: Text(
                        '${remainingBudget.toStringAsFixed(0)} / ${totalBudget.toStringAsFixed(0)}',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: rangeColor,
                        ),
                      ),
                      angle: 90,
                      positionFactor: 0.1,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Thời gian: $period',
            style: const TextStyle(
              fontSize: 16,
              color: Colors.black54,
            ),
          ),
        ],
      ),
    );
  }
}
