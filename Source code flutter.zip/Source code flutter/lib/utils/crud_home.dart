import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:doan_monhoc/model/Transaction.dart'; // Import model Transaction

class CrudHome {
  // Lấy danh sách giao dịch theo userId
  static Future<List<Transaction>> getTransactionsByUserId(String userId) async {
    final response = await http.get(
      Uri.parse('${dotenv.env['BASE_URL']}Transactions/user/$userId'),
    );

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body);
      if (data != null) {
        // Lặp qua từng giao dịch và thêm thông tin từ ExpenseCategory
        List<Transaction> transactions = [];
        for (var e in data) {
          // Lấy thông tin giao dịch
          var transaction = Transaction.fromJson(e);

          // Lấy thông tin type và icon của ExpenseCategory
          var expenseCategoryInfo = await getExpenseCategoryTypeAndIcon(transaction.expenseCategoryId);

          // Thêm thông tin vào transaction
          transaction.expenseCategoryType = expenseCategoryInfo['type'];
          transaction.expenseCategoryIcon = expenseCategoryInfo['icon'];

          // Thêm vào danh sách
          transactions.add(transaction);
        }
        return transactions;
      } else {
        throw Exception('No data found');
      }
    } else {
      throw 'Bạn Chưa Có Giao dịch nào';
    }
  }

  // Lấy thông tin type và icon của ExpenseCategory theo ID

  // Thêm mới một giao dịch
    static Future<void> addTransaction({
      required String userId,
      required String expenseCategoryId,
      required double amount,
      required String date,
      required String description,
    }) async {
      final response = await http.post(
        Uri.parse('${dotenv.env['BASE_URL']}Transactions'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'userId': userId,
          'expenseCategoryId': expenseCategoryId,
          'amount': amount,
          'date': date, // Chuyển đổi DateTime sang chuỗi ISO 8601
          'description': description,
        }),
      );

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception('Failed to add transaction');
    }
  }

  // Cập nhật một giao dịch
  static Future<void> updateTransaction({
    required String id,
    required String userId,
    required String expenseCategoryId,
    required double amount,
    required DateTime date,
    required String description,
  }) async {
    final response = await http.put(
      Uri.parse('${dotenv.env['BASE_URL']}Transactions'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'id': id,
        'userId': userId,
        'expenseCategoryId': expenseCategoryId,
        'amount': amount,
        'date': date.toIso8601String(), // Chuyển đổi DateTime sang chuỗi ISO 8601
        'description': description,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to update transaction');
    }
  }

  // Xóa một giao dịch
  static Future<void> deleteTransaction({
    required String id,
  }) async {
    final response = await http.delete(
      Uri.parse('${dotenv.env['BASE_URL']}Transactions/$id'),
    );

    if (response.statusCode != 204) {
      throw Exception('Failed to delete transaction');
    }
  }
  static Future<Map<String, dynamic>> getExpenseCategoryTypeAndIcon(String expenseCategoryId) async {
    final response = await http.get(
      Uri.parse('${dotenv.env['BASE_URL']}ExpenseCategory/$expenseCategoryId/type-and-icon'),
    );

    if (response.statusCode == 200) {
      // Parse dữ liệu JSON từ phản hồi
      Map<String, dynamic> data = jsonDecode(response.body);
      return data;
    } else {
      throw Exception('Failed to load expense category type and icon');
    }
  }
}
