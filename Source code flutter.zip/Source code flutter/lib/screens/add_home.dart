import 'package:doan_monhoc/model/Transaction.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import thư viện intl để định dạng ngày tháng
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doan_monhoc/utils/crud_home.dart'; // Import CrudHome
import 'package:doan_monhoc/screens/choose_type.dart';
import '../model/ExpenseCategory.dart'; // Import ChooseType

class AddHome extends StatefulWidget {
  @override
  _AddHomeState createState() => _AddHomeState();
}

class _AddHomeState extends State<AddHome> {
  final _formKey = GlobalKey<FormState>();
  String _selectedCategoryId = ''; // Thêm biến để lưu ExpenseCategoryID
  final _tenController = TextEditingController();
  final _soTienController = TextEditingController();
  String _selectedNhom = ''; // Giá trị mặc định
  String _selectedDate = '';


 // Sử dụng String thay vì DateTime

  // Hàm hiển thị DatePicker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = DateFormat('dd/MM/yyyy').format(picked); // Lưu ngày tháng dưới dạng String
      });
    }
  }

  // Hàm hiển thị Bottom Sheet chọn nhóm
  void _showChooseTypeBottomSheet() async {
    final selectedCategory = await showModalBottomSheet<ExpenseCategory>(
      context: context,
      isScrollControlled: true, // Cho phép Bottom Sheet chiếm một phần màn hình
      builder: (BuildContext context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.75, // Chiếm 3/4 màn hình
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: ChooseType(), // Hiển thị ChooseType
        );
      },
    );

    // Xử lý khi người dùng chọn một loại giao dịch
    if (selectedCategory != null) {
      setState(() {
        _selectedNhom = selectedCategory.name; // Cập nhật nhóm được chọn
        _selectedCategoryId = selectedCategory.id;
        print('Đây là _selectedCategoryId: ${_selectedCategoryId}'); // Cập nhật ExpenseCategoryID
      });
    }
  }

  // Hàm thêm mới giao dịch
  Future<void> _addTransaction() async {
    if (_formKey.currentState!.validate()) {
      try {
        // Lấy dữ liệu từ các trường nhập liệu
        final description = _tenController.text;
        final amount = double.parse(_soTienController.text);

        // Lấy userId từ SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        final userId = prefs.getString('id') ?? '';

        if (userId.isEmpty) {
          throw Exception('Không tìm thấy userId. Vui lòng đăng nhập lại.');
        }

        final expenseCategoryId = _selectedCategoryId;

        // In ra các giá trị để kiểm tra
        print('User ID: $userId');
        print('Expense Category ID: $expenseCategoryId');
        print('Amount: $amount');
        print('Date: $_selectedDate'); // In ra ngày tháng dưới dạng String
        print('Description: $description');

        // Gọi API thêm mới giao dịch
        await CrudHome.addTransaction(
          userId: userId,
          expenseCategoryId: expenseCategoryId,
          amount: amount,
          date: _selectedDate, // Sử dụng ngày tháng dưới dạng String
          description: description,
        );

        // Hiển thị thông báo thành công
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Thêm giao dịch thành công!')),
        );
        // Đóng màn hình và trở về màn hình trước đó
        Navigator.pop(context);
      } catch (e) {
        // Hiển thị thông báo lỗi
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi thêm giao dịch: $e')),
        );

        // In ra lỗi nếu có
        print('Error adding transaction: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200], // Màu nền xám nhạt
      appBar: AppBar(
        title: Text('Thêm Mục Mới'),
        centerTitle: true,
        backgroundColor: Colors.green, // Màu xanh lá cho AppBar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Trường nhập Tên
              TextFormField(
                controller: _tenController,
                decoration: InputDecoration(
                  labelText: 'Tên',
                  filled: true, // Đổ màu nền cho TextField
                  fillColor: Colors.white, // Màu nền trắng
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    borderSide: BorderSide(color: Colors.green), // Màu viền khi focus
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Vui lòng nhập tên';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Trường chọn Nhóm (thay thế Dropdown bằng InkWell)
              InkWell(
                onTap: _showChooseTypeBottomSheet, // Hiển thị Bottom Sheet khi ấn
                child: InputDecorator(
                  decoration: InputDecoration(
                    labelText: 'Chọn Nhóm',
                    filled: true, // Đổ màu nền cho trường Nhóm
                    fillColor: Colors.white, // Màu nền trắng
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide(color: Colors.green), // Màu viền khi focus
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_selectedNhom),
                      Icon(Icons.arrow_drop_down, color: Colors.green), // Icon mũi tên
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),

              // Trường nhập Số tiền
              TextFormField(
                controller: _soTienController,
                decoration: InputDecoration(
                  labelText: 'Số tiền',
                  filled: true, // Đổ màu nền cho TextField
                  fillColor: Colors.white, // Màu nền trắng
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    borderSide: BorderSide(color: Colors.green), // Màu viền khi focus
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Vui lòng nhập số tiền';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Vui lòng nhập số hợp lệ';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),

              // Trường chọn Ngày
              InkWell(
                onTap: () => _selectDate(context),
                child: InputDecorator(
                  decoration: InputDecoration(
                    labelText: 'Ngày',
                    filled: true, // Đổ màu nền cho trường Ngày
                    fillColor: Colors.white, // Màu nền trắng
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide(color: Colors.green), // Màu viền khi focus
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _selectedDate.isEmpty
                            ? 'Chọn ngày' // Hiển thị "Chọn ngày" nếu chưa chọn
                            : _selectedDate, // Hiển thị ngày tháng dưới dạng String
                      ),
                      Icon(Icons.calendar_today, color: Colors.green), // Màu icon xanh lá
                    ],
                  ),
                ),
              ),
              SizedBox(height: 24),

              // Hai nút Xác nhận và Huỷ
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // Nút Huỷ
                  ElevatedButton(
                    onPressed: () {
                      // Xử lý khi nhấn Huỷ
                      _tenController.clear();
                      _soTienController.clear();
                      setState(() {
                        _selectedNhom = '';
                        _selectedDate = ''; // Reset ngày tháng
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Đã huỷ thao tác!')),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey, // Màu nền xám cho nút Huỷ
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    ),
                    child: Text('Huỷ', style: TextStyle(color: Colors.white)),
                  ),

                  // Nút Xác nhận
                  ElevatedButton(
                    onPressed: _addTransaction, // Gọi hàm thêm giao dịch
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green, // Màu nền xanh lá cho nút Xác nhận
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    ),
                    child: Text('Xác nhận', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}