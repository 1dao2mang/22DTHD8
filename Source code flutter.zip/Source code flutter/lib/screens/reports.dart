import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart'; // Import thư viện fl_chart

class ReportScreen extends StatefulWidget {
  final double? totalIncome; // Nhận totalIncome từ HomeScreen
  final double? totalExpense; // Nhận totalExpense từ HomeScreen

  const ReportScreen({
    Key? key,
    required this.totalIncome,
    required this.totalExpense,
  }) : super(key: key);

  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  String selectedPeriod = "Monthly"; // Default period

  @override
  Widget build(BuildContext context) {
    // Dữ liệu cho biểu đồ tròn
    final income = widget.totalIncome ?? 0.0;
    final expense = widget.totalExpense ?? 0.0;
    final total = income + expense;

    // Tạo danh sách các phần của biểu đồ tròn
    List<PieChartSectionData> pieChartSections = [
      PieChartSectionData(
        color: Colors.green,
        value: income,
        title: '${((income / total) * 100).toStringAsFixed(1)}%',
        titleStyle: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
      PieChartSectionData(
        color: Colors.red,
        value: expense,
        title: '${((expense / total) * 100).toStringAsFixed(1)}%',
        titleStyle: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    ];

    return Scaffold(
      backgroundColor: Colors.white12,
      appBar: AppBar(
        title: const Text('Thống kê'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Spending Section
            Container(
              color: Colors.green.withOpacity(0.2),
              width: double.infinity,
              child: ExpansionTile(
                leading: const Icon(
                  Icons.shopping_cart,
                  color: Colors.green,
                ),
                title: const Text(
                  "Chi tiêu",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green),
                ),
                children: [
                  Container(
                    color: Colors.white,
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Column(
                        children: [
                          Text(
                            'Tổng chi tiêu: ${expense.toStringAsFixed(2)} VND',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.red,
                            ),
                          ),
                          SizedBox(height: 10),
                          Container(
                            height: 300,
                            child: PieChart(
                              PieChartData(
                                sections: pieChartSections,
                                centerSpaceRadius: 40,
                                sectionsSpace: 0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // Saving Section
            Container(
              color: Colors.green.withOpacity(0.2),
              width: double.infinity,
              child: ExpansionTile(
                leading: const Icon(
                  Icons.savings,
                  color: Colors.green,
                ),
                title: const Text(
                  "Tiết kiệm",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green),
                ),
                children: [
                  Container(
                    color: Colors.white,
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Column(
                        children: [
                          Text(
                            'Tổng tiết kiệm: ${income.toStringAsFixed(2)} VND',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                          SizedBox(height: 10),
                          Container(
                            height: 300,
                            child: PieChart(
                              PieChartData(
                                sections: pieChartSections,
                                centerSpaceRadius: 40,
                                sectionsSpace: 0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // Dropdown for selecting period
            Center(
              child: DropdownButton<String>(
                value: selectedPeriod,
                items: const [
                  DropdownMenuItem(value: "Daily", child: Text("Daily")),
                  DropdownMenuItem(value: "Monthly", child: Text("Monthly")),
                  DropdownMenuItem(value: "Yearly", child: Text("Yearly")),
                ],
                onChanged: (value) {
                  setState(() {
                    selectedPeriod = value!;
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}