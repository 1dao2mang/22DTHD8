import 'package:flutter/material.dart';
import 'package:doan_monhoc/utils/account.dart'; // Import class AccountService

class EmailVerify {
  // Hàm hiển thị bottom sheet
  static void showEmailVerifyBottomSheet(BuildContext context, {required String email}) {
    final TextEditingController _tokenController = TextEditingController(); // Controller để lấy giá trị từ TextField

    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Cho phép bottom sheet mở rộng
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom, // Đảm bảo không bị keyboard che
          ),
          child: Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min, // Chiều cao tự động co lại
              children: [
                // Text hiển thị thông báo
                const Text(
                  "Vui lòng xác thực email của bạn để tiếp tục sử dụng ứng dụng.",
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20), // Khoảng cách giữa text và TextField

                // TextField để nhập Token
                TextField(
                  controller: _tokenController,
                  decoration: const InputDecoration(
                    labelText: 'Nhập Token',
                    border: OutlineInputBorder(),
                    hintText: 'Dán Token từ email vào đây',
                  ),
                ),
                const SizedBox(height: 20), // Khoảng cách giữa TextField và nút

                // Nút "Xác thực"
                ElevatedButton(
                  onPressed: () async {
                    final token = _tokenController.text.trim(); // Lấy giá trị từ TextField

                    if (token.isEmpty) {
                      _showErrorMessage(context, "Vui lòng nhập Token.");
                      return;
                    }

                    // Gọi phương thức xác thực Token
                    final result = await AccountService.verifyEmail(token);

                    // Đóng bottom sheet
                    Navigator.pop(context);

                    // Hiển thị thông báo kết quả
                    if (result['success']) {
                      _showSuccessMessage(context, result['message']);
                    } else {
                      _showErrorMessage(context, result['message']);
                    }
                  },
                  child: const Text("Xác thực"),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Hiển thị thông báo thành công
  static void _showSuccessMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
      ),
    );
  }

  // Hiển thị thông báo lỗi
  static void _showErrorMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }
}