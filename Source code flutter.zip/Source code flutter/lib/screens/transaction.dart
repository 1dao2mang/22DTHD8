import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:doan_monhoc/utils/crud_tsaction.dart';
import 'package:doan_monhoc/utils/account.dart';
import 'package:doan_monhoc/model/ExpenseCategory.dart';
import 'package:doan_monhoc/custom/Dialog.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({Key? key}) : super(key: key);

  @override
  TransactionsScreenState createState() => TransactionsScreenState();
  static TransactionsScreenState? of(BuildContext context) {
    return context.findAncestorStateOfType<TransactionsScreenState>();
  }
}

class TransactionsScreenState extends State<TransactionsScreen> {
  final List<ExpenseCategory> transactions = [];
  bool _showIncomeTransactions = false;
  bool _showExpenseTransactions = false;
  bool _showOtherTransactions = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchTransactions();
  }

  // Hàm lấy dữ liệu giao dịch
  Future<void> fetchTransactions() async {
    print('fetchTransactions được gọi!');
    setState(() {
      _isLoading = true;
    });

    final userData = await AccountService.getUserData();
    final userId = userData['id'];

    print(userId);
    if (userId == null || userId.isEmpty) {
      print('User ID is null or empty.');
      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      List<ExpenseCategory> apiExpenses = await CrudTransaction.getExpenseCategoriesByUserId(userId);
      setState(() {
        transactions.clear();
        transactions.addAll(apiExpenses);
        _isLoading = false;
      });
    } catch (e) {
      print('Failed to fetch transactions: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Hàm hiển thị hộp thoại "Bạn muốn làm gì?"
  void _showActionDialog(ExpenseCategory transaction) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Bạn muốn làm gì?'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton(
                onPressed: () {
                  _deleteTransaction(transaction); // Xử lý xoá
                  Navigator.of(context).pop(); // Đóng hộp thoại
                },
                child: Text('Xoá'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Đóng hộp thoại
                  _updateTransaction(transaction); // Xử lý cập nhật

                },
                child: Text('Cập Nhật'),
              ),
            ],
          ),
        );
      },
    );
  }

  // Hàm xử lý xoá giao dịch
  void _deleteTransaction(ExpenseCategory transaction) async {
    try {
      await CrudTransaction.deleteExpenseCategory(
        id: transaction.id!,
        userId: transaction.userId,
      );
      setState(() {
        transactions.remove(transaction); // Xóa giao dịch khỏi danh sách
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã xoá giao dịch thành công')),
      );
    } catch (e) {
      print('Failed to delete transaction: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Xoá giao dịch thất bại')),
      );
    }
  }

  // Hàm xử lý cập nhật giao dịch
  void _updateTransaction(ExpenseCategory transaction) async {
    // In ra giá trị của transaction.icon để kiểm tra
    print('Giá trị của transaction.icon: ${transaction.icon}');

    // Mở hộp thoại CustomTransactionDialog với dữ liệu hiện tại của giao dịch
    final result = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return CustomTransactionDialog(
          initialName: transaction.name, // Truyền tên hiện tại
          initialIcon: transaction.icon, // Truyền mã Unicode của biểu tượng hiện tại
          initialType: transaction.type, // Truyền loại hiện tại
          onConfirm: (String name, String iconUnicode, int type, String userId) async {
            try {
              // Gọi API để cập nhật giao dịch
              await CrudTransaction.updateExpenseCategory(
                id: transaction.id!,
                userId: userId,
                name: name,
                icon: iconUnicode,
                type: type,
              );

              // Cập nhật danh sách giao dịch
              setState(() {
                transaction.name = name;
                transaction.icon = iconUnicode;
                transaction.type = type;
              });

              // Hiển thị thông báo thành công
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Cập nhật giao dịch thành công')),
              );

              return true; // Trả về true để đóng hộp thoại
            } catch (e) {
              print('Failed to update transaction: $e');
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Cập nhật giao dịch thất bại')),
              );
              return false; // Trả về false nếu có lỗi
            }
          },
          onConfirmCallback: () {
            // Callback khi xác nhận (tạm thời không cần làm gì)
          },
        );
      },
    );

    // Nếu cập nhật thành công, làm mới danh sách giao dịch
    if (result == true) {
      fetchTransactions();
    }
  }

  @override
  Widget build(BuildContext context) {
    final incomeTransactions = transactions.where((t) => t.type == 1).toList();
    final expenseTransactions = transactions.where((t) => t.type == 2).toList();
    final otherTransactions = transactions.where((t) => t.type == 3).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Text('Danh sách giao dịch'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : ListView(
        children: [
          _buildExpandableLabel(
            title: 'Tiền mặt',
            transactions: incomeTransactions,
            isExpanded: _showIncomeTransactions,
            onToggle: () {
              setState(() {
                _showIncomeTransactions = !_showIncomeTransactions;
              });
            },
          ),
          _buildExpandableLabel(
            title: 'Chi tiêu',
            transactions: expenseTransactions,
            isExpanded: _showExpenseTransactions,
            onToggle: () {
              setState(() {
                _showExpenseTransactions = !_showExpenseTransactions;
              });
            },
          ),
          _buildExpandableLabel(
            title: 'Các giao dịch khác',
            transactions: otherTransactions,
            isExpanded: _showOtherTransactions,
            onToggle: () {
              setState(() {
                _showOtherTransactions = !_showOtherTransactions;
              });
            },
          ),
        ],
      ),
    );
  }

  // Widget xây dựng label có thể mở rộng
  Widget _buildExpandableLabel({
    required String title,
    required List<ExpenseCategory> transactions,
    required bool isExpanded,
    required Function() onToggle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: onToggle,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
            padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(25.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.1),
                  blurRadius: 5,
                  spreadRadius: 1,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                FaIcon(
                  title == 'Tiền mặt'
                      ? FontAwesomeIcons.dollarSign
                      : title == 'Chi tiêu'
                      ? FontAwesomeIcons.shoppingCart
                      : FontAwesomeIcons.ellipsisH,
                  size: 24.0,
                  color: Colors.green,
                ),
                const SizedBox(width: 10.0),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                ),
                Icon(
                  isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                  color: Colors.green,
                ),
              ],
            ),
          ),
        ),
        AnimatedCrossFade(
          firstChild: Container(),
          secondChild: Column(
            children: transactions.map((transaction) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 16.0),
                child: GestureDetector(
                  onTap: () {
                    _showActionDialog(transaction); // Hiển thị hộp thoại khi nhấn vào giao dịch
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 1,
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.green.withOpacity(0.2),
                        child: Icon(
                          IconDataSolid(int.parse('0x${transaction.icon}')),
                          color: Colors.green,
                        ),
                      ),
                      title: Text(
                        transaction.name,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          crossFadeState: isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
          duration: const Duration(milliseconds: 300),
        ),
      ],
    );
  }
}