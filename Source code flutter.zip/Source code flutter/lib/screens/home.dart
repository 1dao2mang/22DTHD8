import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doan_monhoc/utils/crud_home.dart'; // Import service
import 'package:doan_monhoc/model/Transaction.dart'; // Import model
import 'package:font_awesome_flutter/font_awesome_flutter.dart'; // Thêm package này để hỗ trợ IconDataSolid
import 'package:intl/intl.dart';
import 'package:doan_monhoc/screens/reports.dart';
import 'package:doan_monhoc/screens/add_home.dart'; // Import package intl

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Transaction>> futureTransactions;
  String userId = ''; // Biến để lưu userId

  // Biến để lưu tổng tiền mặt (màu xanh) và tổng chi tiêu (màu đỏ)
  double totalIncome = 0.0; // Tổng tiền mặt (type 1)
  double totalExpense = 0.0; // Tổng chi tiêu (type 2 hoặc 3)

  @override
  void initState() {
    super.initState();
    // Lấy userId từ SharedPreferences và sau đó lấy danh sách giao dịch
    _loadUserIdAndTransactions();
  }

  // Hàm lấy userId từ SharedPreferences và tải danh sách giao dịch
  Future<void> _loadUserIdAndTransactions() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getString('id') ?? ''; // Lấy userId từ SharedPreferences
    });

    if (userId.isNotEmpty) {
      // Nếu có userId, lấy danh sách giao dịch
      setState(() {
        futureTransactions = CrudHome.getTransactionsByUserId(userId);
      });
    } else {
      // Nếu không có userId, hiển thị thông báo lỗi
      setState(() {
        futureTransactions = Future.error('Không tìm thấy userId. Vui lòng đăng nhập lại.');
      });
    }
  }

  // Hàm xóa giao dịch
  Future<void> _deleteTransaction(String transactionId) async {
    try {
      print('Deleting transaction with ID: $transactionId'); // Debug
      await CrudHome.deleteTransaction(id: transactionId);
      print('Transaction deleted successfully'); // Debug

      // Sau khi xóa thành công, cập nhật danh sách giao dịch
      setState(() {
        futureTransactions = CrudHome.getTransactionsByUserId(userId);
      });

      // Hiển thị thông báo xóa thành công
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Xóa giao dịch thành công!')),
      );
    } catch (e) {
      // Xử lý lỗi nếu có
      print('Error deleting transaction: $e'); // Debug
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi xóa giao dịch: $e')),
      );
    }
  }

  // Hàm hiển thị hộp thoại tùy chọn
  void _showOptionsDialog(Transaction transaction) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(Icons.delete, color: Colors.red),
                title: Text('Xoá'),
                onTap: () {
                  Navigator.pop(context); // Đóng hộp thoại
                  _deleteTransaction(transaction.id); // Xóa giao dịch
                },
              ),
              ListTile(
                leading: Icon(Icons.edit, color: Colors.blue),
                title: Text('Cập Nhật'),
                onTap: () {
                  Navigator.pop(context); // Đóng hộp thoại
                  _navigateToUpdateScreen(transaction); // Điều hướng đến màn hình cập nhật
                },
              ),
            ],
          ),
        );
      },
    );
  }

  // Hàm điều hướng đến màn hình cập nhật
  void _navigateToUpdateScreen(Transaction transaction) {
    // TODO: Thêm logic điều hướng đến màn hình cập nhật
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Chức năng cập nhật chưa được triển khai')),
    );
  }

  // Hàm tính toán số dư
  double _calculateBalance(List<Transaction> transactions) {
    totalIncome = 0.0; // Reset tổng tiền mặt
    totalExpense = 0.0; // Reset tổng chi tiêu

    for (var transaction in transactions) {
      if (transaction.expenseCategoryType == 1) {
        totalIncome += transaction.amount; // Cộng vào tổng tiền mặt
      } else if (transaction.expenseCategoryType == 2 || transaction.expenseCategoryType == 3) {
        totalExpense += transaction.amount; // Cộng vào tổng chi tiêu
      }
    }

    return totalIncome - totalExpense; // Số dư hiện tại
  }

  void _navigateToReportScreen(BuildContext context) {
    // Truyền totalIncome và totalExpense qua constructor của ReportScreen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ReportScreen(
          totalIncome: totalIncome,
          totalExpense: totalExpense,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Phần hiển thị số dư
            FutureBuilder<List<Transaction>>(
              future: futureTransactions,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(child: Text('Không có giao dịch nào.'));
                } else {
                  List<Transaction> transactions = snapshot.data!;
                  double balance = _calculateBalance(transactions); // Tính toán số dư
                  Color balanceColor = balance >= 0 ? Colors.green : Colors.red; // Màu sắc dựa trên số dư

                  return Column(
                    children: [
                      // Hiển thị số dư hiện tại
                      Container(
                        padding: EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                          color: balanceColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Số dư hiện tại',
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.grey[700],
                              ),
                            ),
                            SizedBox(height: 8.0),
                            Text(
                              '${NumberFormat.currency(locale: 'vi_VN', symbol: 'VND').format(balance)}',
                              style: TextStyle(
                                fontSize: 28.0,
                                fontWeight: FontWeight.bold,
                                color: balanceColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                }
              },
            ),
            SizedBox(height: 20.0),
            // Tiêu đề "Giao Dịch Gần Đây"
            Text(
              'Giao Dịch Gần Đây',
              style: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10.0),
            // Danh sách giao dịch
            Expanded(
              child: FutureBuilder<List<Transaction>>(
                future: futureTransactions,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('${snapshot.error}'));
                  } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return Center(child: Text('Không có giao dịch nào.'));
                  } else {
                    List<Transaction> transactions = snapshot.data!;
                    return ListView.builder(
                      itemCount: transactions.length,
                      itemBuilder: (context, index) {
                        Transaction transaction = transactions[index];
                        // Xác định màu sắc dựa trên type
                        Color iconColor = transaction.expenseCategoryType == 1
                            ? Colors.green
                            : Colors.red;

                        // Chuyển đổi mã Unicode thành IconData
                        IconData iconData = _getIconDataFromUnicode(transaction.expenseCategoryIcon);

                        return Dismissible(
                          key: Key(transaction.id),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            color: Colors.red,
                            alignment: Alignment.centerRight,
                            padding: EdgeInsets.only(right: 20.0),
                            child: Icon(
                              Icons.delete,
                              color: Colors.white,
                            ),
                          ),
                          onDismissed: (direction) {
                            _deleteTransaction(transaction.id);
                          },
                          child: ListTile(
                            leading: Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: iconColor.withOpacity(0.2),
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Icon(
                                  iconData,
                                  color: iconColor,
                                  size: 20,
                                ),
                              ),
                            ),
                            title: Text(transaction.description),
                            subtitle: Text(
                              DateFormat('dd/MM/yyyy').format(transaction.date),
                            ),
                            trailing: Text(
                              '${transaction.amount} VND',
                              style: TextStyle(
                                color: iconColor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            onTap: () {
                              _showOptionsDialog(transaction);
                            },
                          ),
                        );
                      },
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Hàm để chuyển đổi mã Unicode thành IconData
  IconData _getIconDataFromUnicode(String? expenseCategoryIcon) {
    if (expenseCategoryIcon == null || expenseCategoryIcon.isEmpty) {
      return Icons.money_off; // Icon mặc định nếu không có mã Unicode
    }
    // Tạo IconData từ mã Unicode
    return IconDataSolid(int.parse('0x${expenseCategoryIcon}'));
  }
}