import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doan_monhoc/utils/account.dart'; // Import AccountService để cập nhật ảnh đại diện
import 'package:permission_handler/permission_handler.dart'; // Thêm package để yêu cầu quyền truy cập
import 'package:doan_monhoc/screens/login.dart'; // Import màn hình đăng nhập
import 'package:doan_monhoc/screens/email_verify.dart'; // Import class EmailVerify

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String fullName = '';
  String email = '';
  String avatarUrl = '';

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  // Hàm lấy thông tin người dùng từ SharedPreferences
  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      fullName = prefs.getString('fullName') ?? 'N/A';
      email = prefs.getString('email') ?? 'N/A';
      avatarUrl = prefs.getString('avatarUrl') ?? '';
    });
  }

  // Hàm hiển thị hộp thoại tùy chọn
  void _showAvatarOptions() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.visibility, color: Colors.blue),
                title: const Text('Xem ảnh đại diện'),
                onTap: () {
                  Navigator.pop(context); // Đóng hộp thoại
                  _viewAvatar(); // Gọi hàm xem ảnh đại diện
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_camera, color: Colors.green),
                title: const Text('Thay đổi ảnh đại diện'),
                onTap: () {
                  Navigator.pop(context); // Đóng hộp thoại
                  _pickImage(); // Gọi hàm chọn ảnh từ thiết bị
                },
              ),
            ],
          ),
        );
      },
    );
  }

  // Hàm xem ảnh đại diện
  void _viewAvatar() {
    if (avatarUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Không có ảnh đại diện để hiển thị.')),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Image.network(
          avatarUrl,
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  // Hàm yêu cầu quyền truy cập bộ nhớ
  Future<void> requestStoragePermission() async {
    final status = await Permission.storage.status;

    if (status.isGranted) {
      print('Quyền truy cập bộ nhớ đã được cấp.');
    } else if (status.isDenied) {
      // Yêu cầu quyền
      final result = await Permission.storage.request();
      if (result.isGranted) {
        print('Quyền truy cập bộ nhớ đã được cấp.');
      } else {
        print('Quyền truy cập bộ nhớ bị từ chối.');
        // Hiển thị thông báo
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Quyền truy cập bộ nhớ bị từ chối.')),
        );
      }
    } else if (status.isPermanentlyDenied) {
      print('Quyền truy cập bộ nhớ bị từ chối vĩnh viễn.');
      // Hiển thị thông báo
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Quyền truy cập bộ nhớ bị từ chối vĩnh viễn.')),
      );
    }
  }

  // Hàm chọn ảnh từ thiết bị
  Future<void> _pickImage() async {
    // Yêu cầu quyền truy cập bộ nhớ
    await requestStoragePermission();

    final picker = ImagePicker();
    try {
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        File image = File(pickedFile.path);
        await _updateAvatar(image);
      } else {
        print('Không có ảnh nào được chọn.');
      }
    } catch (e) {
      print('Lỗi khi chọn ảnh: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi chọn ảnh: $e')),
      );
    }
  }

  // Hàm cập nhật ảnh đại diện
  Future<void> _updateAvatar(File image) async {
    try {
      // Lấy userId từ SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString('id');

      if (userId == null || userId.isEmpty) {
        throw Exception('Không tìm thấy thông tin người dùng.');
      }

      // Gọi phương thức uploadAndUpdateAvatar từ AccountService
      final newAvatarUrl = await AccountService.uploadAndUpdateAvatar(image, userId);

      // Cập nhật SharedPreferences và giao diện
      await prefs.setString('avatarUrl', newAvatarUrl);

      setState(() {
        avatarUrl = newAvatarUrl;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ảnh đại diện đã được cập nhật.')),
      );
    } catch (e) {
      print('Lỗi khi cập nhật ảnh đại diện: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Cập nhật ảnh đại diện thất bại: $e')),
      );
    }
  }

  // Hàm đăng xuất
  Future<void> _logout() async {
    try {
      // Xóa dữ liệu người dùng từ SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear(); // Xóa tất cả dữ liệu đã lưu

      // Chuyển hướng đến màn hình đăng nhập
      Navigator.of(context).pushReplacementNamed('/'); // Thay thế màn hình hiện tại bằng màn hình đăng nhập
    } catch (e) {
      print('Lỗi khi đăng xuất: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đăng xuất thất bại. Vui lòng thử lại.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cài đặt'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            // Avatar and Email
            Column(
              children: [
                GestureDetector(
                  onTap: _showAvatarOptions, // Hiển thị hộp thoại tùy chọn khi nhấn vào ảnh đại diện
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: avatarUrl.isNotEmpty && Uri.tryParse(avatarUrl)?.hasAbsolutePath == true
                        ? NetworkImage(avatarUrl) // Hiển thị ảnh từ URL
                        : null, // Không sử dụng ảnh mặc định từ assets
                    child: avatarUrl.isEmpty
                        ? const Icon(Icons.person, size: 50, color: Colors.white) // Hiển thị icon mặc định
                        : null,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  fullName,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 5),
                Text(
                  email,
                  style: const TextStyle(fontSize: 16, color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 30),
            // Menu Options
            ListTile(
              leading: const Icon(Icons.person, color: Colors.green),
              title: const Text(
                'Tài khoản',
                style: TextStyle(fontSize: 16),
              ),
              onTap: () {
                // Gọi phương thức hiển thị bottom sheet xác thực email
                EmailVerify.showEmailVerifyBottomSheet(
                  context,
                  email: email, // Truyền email của người dùng
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.settings, color: Colors.green),
              title: const Text(
                'Cài đặt',
                style: TextStyle(fontSize: 16),
              ),
              onTap: () {},
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.contact_support, color: Colors.green),
              title: const Text(
                'Liên hệ',
                style: TextStyle(fontSize: 16),
              ),
              onTap: () {},
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text(
                'Đăng xuất',
                style: TextStyle(fontSize: 16, color: Colors.red),
              ),
              onTap: _logout, // Gọi hàm đăng xuất
            ),
            const Divider(),
          ],
        ),
      ),
    );
  }
}