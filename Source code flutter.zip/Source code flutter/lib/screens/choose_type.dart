import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:doan_monhoc/model/ExpenseCategory.dart';
import 'package:doan_monhoc/utils/crud_tsaction.dart';
import 'package:doan_monhoc/utils/account.dart';

class ChooseType extends StatefulWidget {
  const ChooseType({Key? key}) : super(key: key);

  @override
  _ChooseTypeState createState() => _ChooseTypeState();
}

class _ChooseTypeState extends State<ChooseType> {
  final List<ExpenseCategory> categories = [];
  bool _showIncomeCategories = false;
  bool _showExpenseCategories = false;
  bool _showOtherCategories = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchCategories();
  }

  // Hàm lấy danh sách các loại giao dịch
  Future<void> fetchCategories() async {
    setState(() {
      _isLoading = true;
    });

    final userData = await AccountService.getUserData();
    final userId = userData['id'];

    if (userId == null || userId.isEmpty) {
      print('User ID is null or empty.');
      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      List<ExpenseCategory> apiCategories = await CrudTransaction.getExpenseCategoriesByUserId(userId);
      setState(() {
        categories.clear();
        categories.addAll(apiCategories);
        _isLoading = false;
      });
    } catch (e) {
      print('Failed to fetch categories: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final incomeCategories = categories.where((c) => c.type == 1).toList();
    final expenseCategories = categories.where((c) => c.type == 2).toList();
    final otherCategories = categories.where((c) => c.type == 3).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Text('Chọn Loại Giao Dịch'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : ListView(
        children: [
          _buildExpandableLabel(
            title: 'Tiền mặt',
            categories: incomeCategories,
            isExpanded: _showIncomeCategories,
            onToggle: () {
              setState(() {
                _showIncomeCategories = !_showIncomeCategories;
              });
            },
          ),
          _buildExpandableLabel(
            title: 'Chi tiêu',
            categories: expenseCategories,
            isExpanded: _showExpenseCategories,
            onToggle: () {
              setState(() {
                _showExpenseCategories = !_showExpenseCategories;
              });
            },
          ),
          _buildExpandableLabel(
            title: 'Các loại khác',
            categories: otherCategories,
            isExpanded: _showOtherCategories,
            onToggle: () {
              setState(() {
                _showOtherCategories = !_showOtherCategories;
              });
            },
          ),
        ],
      ),
    );
  }

  // Widget xây dựng label có thể mở rộng
  Widget _buildExpandableLabel({
    required String title,
    required List<ExpenseCategory> categories,
    required bool isExpanded,
    required Function() onToggle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: onToggle,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
            padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 20.0),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(25.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.1),
                  blurRadius: 5,
                  spreadRadius: 1,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                FaIcon(
                  title == 'Tiền mặt'
                      ? FontAwesomeIcons.dollarSign
                      : title == 'Chi tiêu'
                      ? FontAwesomeIcons.shoppingCart
                      : FontAwesomeIcons.ellipsisH,
                  size: 24.0,
                  color: Colors.green,
                ),
                const SizedBox(width: 10.0),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                ),
                Icon(
                  isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                  color: Colors.green,
                ),
              ],
            ),
          ),
        ),
        AnimatedCrossFade(
          firstChild: Container(),
          secondChild: Column(
            children: categories.map((category) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 16.0),
                child: GestureDetector(
                  onTap: () {
                    // Xử lý khi chọn một loại giao dịch
                    _onCategorySelected(category);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 1,
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.green.withOpacity(0.2),
                        child: Icon(
                          IconDataSolid(int.parse('0x${category.icon}')),
                          color: Colors.green,
                        ),
                      ),
                      title: Text(
                        category.name,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          crossFadeState: isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
          duration: const Duration(milliseconds: 300),
        ),
      ],
    );
  }

  void _onCategorySelected(ExpenseCategory category) {
    // In ra thông tin loại giao dịch được chọn (cả id và name)
    print('Selected category - ID: ${category.id}, Name: ${category.name}');

    // Đóng màn hình và trả về loại giao dịch được chọn
    Navigator.pop(context, category);
  }
}