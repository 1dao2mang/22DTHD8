import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:doan_monhoc/screens/main_screens.dart';
import 'package:doan_monhoc/screens/register.dart';
import 'package:doan_monhoc/utils/account.dart'; // Import AccountService để gọi API
import 'package:flutter/services.dart';
import '../service/auth.dart'; // Import class LocalAuth
import 'package:local_auth/local_auth.dart';

import '../service/local_auth.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isPasswordHidden = true;
  bool _isLoading = false;
  final LocalAuth _localAuth = LocalAuth(); // Khởi tạo LocalAuth

  @override
  void initState() {
    super.initState();
    _localAuth.checkBiometricSupport(); // Kiểm tra hỗ trợ sinh trắc học
  }

  Future<void> _login() async {
    setState(() {
      _isLoading = true;
    });

    // Kiểm tra xem thiết bị có hỗ trợ sinh trắc học không
    if (_localAuth.supportState == SupportState.supported) {
      // Kiểm tra xem có sinh trắc học nào được đăng ký không
      final List<BiometricType> availableBiometrics = await _localAuth.getAvailableBiometrics();
      if (availableBiometrics.isEmpty) {
        // Nếu không có sinh trắc học nào được đăng ký, hiển thị thông báo
        _showErrorDialog('Error', 'Vui lòng đăng ký vân tay hoặc Face ID trong cài đặt thiết bị.');
        setState(() {
          _isLoading = false;
        });
        return;
      }

      // Thực hiện xác thực sinh trắc học
      try {
        final bool authenticated = await _localAuth.authenticateWithBiometrics();
        if (!authenticated) {
          // Nếu xác thực sinh trắc học thất bại, hiển thị thông báo
          _showErrorDialog('Error', 'Biometric authentication failed.');
          setState(() {
            _isLoading = false;
          });
          return;
        }
      } on PlatformException catch (e) {
        // Xử lý lỗi nếu có
        print('Lỗi xác thực: ${e.message}');
        _showErrorDialog('Error', 'Đã xảy ra lỗi trong quá trình xác thực.');
        setState(() {
          _isLoading = false;
        });
        return;
      }
    } else {
      // Nếu thiết bị không hỗ trợ sinh trắc học, hiển thị thông báo
      _showErrorDialog('Error', 'Thiết bị không hỗ trợ sinh trắc học.');
      setState(() {
        _isLoading = false;
      });
      return;
    }

    // Tiếp tục đăng nhập bằng email và mật khẩu
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      _showErrorDialog('Error', 'Email and password cannot be empty.');
      setState(() {
        _isLoading = false;
      });
      return;
    }

    final response = await AccountService.login(email, password);

    if (response['success']) {
      // Nếu đăng nhập thành công, chuyển đến MainScreen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => MainScreen(),
        ),
      );
    } else {
      // Hiển thị thông báo lỗi nếu đăng nhập thất bại
      _showErrorDialog('Login Failed', response['message']);
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _showErrorDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 50),
              const Text(
                'Welcome',
                style: TextStyle(
                  fontSize: 28.0,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8.0),
              const Text(
                'Enter your Email address to sign in.\nEnjoy your food :)',
                style: TextStyle(fontSize: 16.0, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24.0),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.green, width: 2.0),
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: const BorderSide(color: Colors.green),
                  ),
                  suffixIcon: const Icon(Icons.email),
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Password',
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.green, width: 2.0),
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.green),
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isPasswordHidden ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _isPasswordHidden = !_isPasswordHidden;
                      });
                    },
                  ),
                ),
                obscureText: _isPasswordHidden,
              ),
              const SizedBox(height: 8.0),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    // Thêm logic quên mật khẩu
                  },
                  child: const Text(
                    'Forgot Password?',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _isLoading ? null : _login,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(vertical: 12.0),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(
                  color: Colors.white,
                )
                    : const Text(
                  'SIGN IN',
                  style: TextStyle(color: Colors.white, fontSize: 18.0),
                ),
              ),
              const SizedBox(height: 16.0),
              const Center(
                child: Text(
                  "Don't have account?",
                  style: TextStyle(color: Colors.grey),
                ),
              ),
              Center(
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RegisterScreen()),
                    );
                  },
                  child: const Text(
                    'Create new account.',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
              ),
              const SizedBox(height: 8.0),
              const Center(
                child: Text('Or', style: TextStyle(color: Colors.grey)),
              ),
              const SizedBox(height: 8.0),
              ElevatedButton.icon(
                onPressed: () {
                  // Thêm logic kết nối Facebook
                },
                icon: const Icon(Icons.facebook, color: Colors.white),
                label: const Text(
                  'CONNECT WITH FACEBOOK',
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[800],
                ),
              ),
              const SizedBox(height: 8.0),
              ElevatedButton.icon(
                onPressed: () {
                  // Thêm logic kết nối Google
                },
                icon: const Icon(Icons.g_mobiledata, color: Colors.white),
                label: const Text(
                  'CONNECT WITH GOOGLE',
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}