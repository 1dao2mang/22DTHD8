import 'package:flutter/material.dart';
import 'package:doan_monhoc/screens/home.dart';
import 'package:doan_monhoc/screens/transaction.dart';
import 'package:doan_monhoc/screens/settings.dart';
import 'package:doan_monhoc/screens/reports.dart';
import 'package:doan_monhoc/custom/bottomnavcus.dart';
import 'package:doan_monhoc/custom/cusfloating.dart';
import 'package:doan_monhoc/custom/Dialog.dart'; // Import CustomTransactionDialog
import 'package:doan_monhoc/utils/crud_tsaction.dart';
import 'package:doan_monhoc/screens/transaction.dart'; // Import CrudTransaction để gọi API
import 'package:doan_monhoc/screens/add_home.dart'; // Import AddHome

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  bool _showLabel = false; // Ban đầu ẩn label
  final GlobalKey<TransactionsScreenState> _transactionsScreenKey = GlobalKey();
  late List<Widget> _pages;
  double totalIncome = 0.0;
  double totalExpense = 0.0;
  @override
  void initState() {
    super.initState();
    // Khởi tạo danh sách các trang
    _pages = [
      HomeScreen(), // Trang chủ
      TransactionsScreen(
        key: _transactionsScreenKey,
      ), // Giao dịch
      ReportScreen(
          totalIncome: totalIncome ?? 0.0, // Sử dụng 0.0 nếu totalIncome là null
          totalExpense: totalExpense ?? 0.0,), // Thống kê
      const SettingsScreen(), // Cài đặt
    ];
  }

  // Xử lý sự kiện khi chuyển tab
  void _handleTabChange(int index) {
    setState(() {
      _currentIndex = index;
      // Hiển thị label nếu là HomeScreen, TransactionsScreen hoặc ReportScreen
      if (index == 0 || index == 1 || index == 2) {
        _showLabel = true;
        _hideLabelAfterDelay();
      } else {
        _showLabel = false; // Ẩn label nếu không phải các trang trên
      }
    });
  }

  // Ẩn label sau 3 giây
  void _hideLabelAfterDelay() async {
    await Future.delayed(Duration(seconds: 3));
    if (mounted && (_currentIndex == 0 || _currentIndex == 1 || _currentIndex == 2)) {
      setState(() {
        _showLabel = false;
      });
    }
  }

  // Hiển thị dialog thêm giao dịch
  void _showTransactionDialog() async {
    final result = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return CustomTransactionDialog(
          onConfirm: (String name, String icon, int type, String userId) async {
            try {
              // Gọi API thêm loại giao dịch
              await CrudTransaction.addExpenseCategory(
                userId: userId,
                name: name,
                type: type,
                icon: icon,
              );

              // Hiển thị thông báo thành công
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Thêm loại giao dịch thành công!')),
              );

              return true; // Trả về true nếu thành công
            } catch (error) {
              print('Lỗi khi thêm loại giao dịch: $error');
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Lỗi khi thêm loại giao dịch: $error')),
              );
              return false; // Trả về false nếu có lỗi
            }
          },
          onConfirmCallback: () {
            // Gọi callback để làm mới dữ liệu
            _updateTransactionsScreen();
          },
        );
      },
    );

    // Nếu thành công, cập nhật TransactionsScreen
    if (result == true) {
      _updateTransactionsScreen();
    }
  }

  // Cập nhật dữ liệu trên TransactionsScreen
  void _updateTransactionsScreen() {
    print('Callback onDataUpdated được gọi!');
    // Sử dụng GlobalKey để truy cập TransactionsScreenState
    final transactionsScreenState = _transactionsScreenKey.currentState;
    if (transactionsScreenState != null) {
      transactionsScreenState.fetchTransactions(); // Gọi fetchTransactions trực tiếp
    } else {
      print('Không tìm thấy TransactionsScreen trong cây widget.');
    }
  }

  // Hiển thị AddHome dưới dạng bottom sheet
  void _showAddHomeBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Cho phép bottom sheet chiếm một phần màn hình
      backgroundColor: Colors.transparent, // Nền trong suốt
      builder: (BuildContext context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.75, // Chiếm 75% màn hình
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: AddHome(), // Hiển thị AddHome
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _pages[_currentIndex], // Hiển thị trang hiện tại
          // Hiển thị label "Thêm chi tiêu", "Danh sách chi tiêu" hoặc "Tạo ngân sách"
          if (_currentIndex == 0 || _currentIndex == 1 || _currentIndex == 2)
            Positioned(
              left: 0,
              right: 0,
              bottom: kBottomNavigationBarHeight - 20, // Điều chỉnh vị trí của label
              child: Center(
                child: AnimatedOpacity(
                  opacity: _showLabel ? 1.0 : 0.0, // Độ trong suốt
                  duration: Duration(milliseconds: 500), // Hiệu ứng fade in/out
                  child: CustomPaint(
                    painter: SpeechBubblePainter(),
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Text(
                        _currentIndex == 0
                            ? 'Thêm chi tiêu'
                            : _currentIndex == 1
                            ? 'Danh sách chi tiêu'
                            : 'Tạo ngân sách',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      // FloatingActionButton chỉ hiển thị ở HomeScreen, TransactionsScreen hoặc ReportScreen
      floatingActionButton: _currentIndex == 0 || _currentIndex == 1 || _currentIndex == 2
          ? CustomFloatingActionButton(
        currentIndex: _currentIndex,
        onPressed: _currentIndex == 1
            ? _showTransactionDialog
            : _currentIndex == 0
            ? _showAddHomeBottomSheet // Hiển thị AddHome khi nhấn vào button của HomeScreen
            : () {
          // Xử lý sự kiện cho ReportScreen
          print('ReportScreen action');
        },
      )
          : null, // Ẩn FAB nếu _currentIndex == 3 (Settings)
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: const CircularNotchedRectangle(), // Tạo hình khuyết cho FAB
        notchMargin: 8.0, // Khoảng cách từ mép
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            BottomNavButton(
              icon: Icons.home,
              isSelected: _currentIndex == 0,
              onTap: () => _handleTabChange(0),
            ),
            BottomNavButton(
              icon: Icons.list,
              isSelected: _currentIndex == 1,
              onTap: () => _handleTabChange(1),
            ),
            const SizedBox(width: 40), // Khoảng trống cho FloatingActionButton
            BottomNavButton(
              icon: Icons.bar_chart,
              isSelected: _currentIndex == 2,
              onTap: () => _handleTabChange(2),
            ),
            BottomNavButton(
              icon: Icons.settings,
              isSelected: _currentIndex == 3,
              onTap: () => _handleTabChange(3),
            ),
          ],
        ),
      ),
    );
  }
}

// CustomPainter để vẽ Rectangle Speech Bubble
class SpeechBubblePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = Colors.green
      ..style = PaintingStyle.fill;

    final double width = size.width;
    final double height = size.height;
    final double radius = 8.0;
    final double tailWidth = 12.0;
    final double tailHeight = 10.0;

    // Vẽ hình chữ nhật bo góc
    final RRect rect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, width, height),
      Radius.circular(radius),
    );
    canvas.drawRRect(rect, paint);

    // Vẽ đuôi (tail) của bong bóng
    final Path path = Path();
    path.moveTo(width / 2 - tailWidth / 2, height);
    path.lineTo(width / 2, height + tailHeight);
    path.lineTo(width / 2 + tailWidth / 2, height);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}