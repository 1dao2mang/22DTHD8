import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart'; // Import dotenv
import 'package:doan_monhoc/screens/login.dart'; // Import màn hình đăng nhập
import 'package:doan_monhoc/screens/main_screens.dart'; // Import màn hình chính

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load file .env
  await dotenv.load(fileName: ".env");

  // Override SSL verification
  HttpOverrides.global = MyHttpOverrides();

  runApp(const MyApp());
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quản Lý Tài Chính',
      theme: ThemeData(
        primarySwatch: Colors.green, // Đổi màu chủ đạo thành màu xanh lá
      ),
      initialRoute: '/', // Route mặc định
      routes: {
        '/': (context) =>  LoginScreen(), // Màn hình đăng nhập
        '/main': (context) => const MainScreen(), // Màn hình chính
      },
    );
  }
}