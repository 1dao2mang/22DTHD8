﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using NEW_API_DA_NHOM10.Models;
using NEW_API_DA_NHOM10.Repositories;
using test_api.Models;



var builder = WebApplication.CreateBuilder(args);

// Thêm dịch vụ DbContext
builder.Services.AddDbContext<AuthDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped<EmailService>();
builder.Services.AddSingleton<IConfiguration>(builder.Configuration);
// Đăng ký các Repository
builder.Services.AddScoped<IUserRepository, UserRepository>();
//Đăng khí dịch vụ của các giao dịch
builder.Services.AddScoped<ITransactionRepository, TransactionRepository>();
//Dịch vụ của Loại Giao dịch
builder.Services.AddScoped<IExpenseCategoryRepository, ExpenseCategoryRepository>();
// Thêm dịch vụ Controllers
builder.Services.AddControllers();
builder.Services.AddScoped<IDefaultExpenseService, DefaultExpenseService>();
// Thêm Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Cấu hình Middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseStaticFiles();
app.UseHttpsRedirection();
app.MapControllers();
app.Run();