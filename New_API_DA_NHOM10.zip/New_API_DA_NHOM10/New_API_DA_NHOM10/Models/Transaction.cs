﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NEW_API_DA_NHOM10.Models
{
    public class Transaction
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        public Guid UserId { get; set; }

        [Required]
        public Guid ExpenseCategoryId { get; set; }

        [Required]
        [Range(0, double.MaxValue)]
        public decimal Amount { get; set; } // Số tiền giao dịch

        [Required]
        public DateTime Date { get; set; } // Ngày giao dịch

        [MaxLength(200)]
        public string? Description { get; set; } // Mô tả chi tiết (tùy chọn)

        // Quan hệ nhiều-một với User
        [ForeignKey("UserId")]
        public User User { get; set; }

        // Quan hệ nhiều-một với ExpenseCategory
        [ForeignKey("ExpenseCategoryId")]
        public ExpenseCategory ExpenseCategory { get; set; }
    }
}