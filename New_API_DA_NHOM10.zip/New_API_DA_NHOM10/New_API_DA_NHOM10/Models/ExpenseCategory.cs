﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NEW_API_DA_NHOM10.Models
{
    public class ExpenseCategory
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        [MaxLength(50)]
        public string Name { get; set; } // Tên loại giao dịch

        [Required]
        public string Icon { get; set; } // Mã biểu tượng (ví dụ: 0xf155 cho dollar-sign)

        [Required]
        public int Type { get; set; } // 1: Tiền mặt, 2: Chi tiêu, 3: Các giao dịch khác

        [Required]
        public Guid UserId { get; set; } // Khóa ngoại tham chiếu đến User

        // Quan hệ nhiều-một với User
        [ForeignKey("UserId")]
        public User User { get; set; }

        // Quan hệ một-nhiều với Transaction
        public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
    }
}