﻿namespace New_API_DA_NHOM10.Models
{
    public class TransactionResponseDto
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public Guid ExpenseCategoryId { get; set; }
        public decimal Amount { get; set; }
        public string Date { get; set; } // Kiểu string để trả về định dạng dd/MM/yyyy
        public string Description { get; set; }
    }
}
