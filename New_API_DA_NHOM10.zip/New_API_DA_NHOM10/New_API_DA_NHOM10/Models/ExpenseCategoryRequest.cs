﻿namespace New_API_DA_NHOM10.Models
{
    public class ExpenseCategoryRequest
    {
        public Guid Id { get; set; } // Chỉ cần cho cập nhật, có thể null khi thêm mới
        public string Name { get; set; }
        public string Icon { get; set; }
        public int Type { get; set; }
        public Guid UserId { get; set; }
    }
}
