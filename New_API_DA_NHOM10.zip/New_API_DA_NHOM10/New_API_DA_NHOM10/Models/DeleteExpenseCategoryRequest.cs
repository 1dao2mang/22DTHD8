﻿namespace New_API_DA_NHOM10.Models
{
    public class DeleteExpenseCategoryRequest
    {
        public Guid Id { get; set; }  // ID của danh mục chi tiêu cần xóa
        public Guid UserId { get; set; }
    }
}
