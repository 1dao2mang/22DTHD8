﻿using System.ComponentModel.DataAnnotations;

namespace New_API_DA_NHOM10.Models
{
    public class LoginModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [MinLength(6)]
        public string Password { get; set; }
    }
}
