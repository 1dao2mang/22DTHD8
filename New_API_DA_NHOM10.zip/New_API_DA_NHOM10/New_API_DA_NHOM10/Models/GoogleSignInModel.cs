﻿namespace New_API_DA_NHOM10.Models
{
    public class GoogleSignInModel
    {
        public string FullName { get; set; } // Tên người dùng từ Google
        public string Email { get; set; } // Email từ Google
        public string GoogleId { get; set; } // Google ID Token
        public string AvatarUrl { get; set; } // URL ảnh đại diện từ Google
    }
}
