﻿namespace New_API_DA_NHOM10.Models
{
    public class UpdateAvatarModel
    {
        public Guid UserId { get; set; }
        public string AvatarUrl { get; set; }
    }
}
