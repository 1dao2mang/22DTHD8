﻿using System.ComponentModel.DataAnnotations;

namespace NEW_API_DA_NHOM10.DTOs
{
    public class AddTransactionDto
    {
        public Guid UserId { get; set; }
        public Guid ExpenseCategoryId { get; set; }
        public decimal Amount { get; set; }
        public string Date { get; set; } // Kiểu string để nhận giá trị dd/MM/yyyy
        public string Description { get; set; }
    }
}