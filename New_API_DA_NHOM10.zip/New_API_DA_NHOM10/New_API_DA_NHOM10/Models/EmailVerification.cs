﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NEW_API_DA_NHOM10.Models
{
    public class EmailVerification
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required]
        public string Token { get; set; } = Guid.NewGuid().ToString(); // Token xác thực

        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow; // Thời gian tạo token

        public bool IsVerified { get; set; } = false; // Trạng thái xác thực

        [Required]
        public Guid UserId { get; set; } // Liên kết với User

        [ForeignKey("UserId")]
        public User User { get; set; } // Navigation property để truy cập User
    }
}