﻿using Microsoft.EntityFrameworkCore;

namespace NEW_API_DA_NHOM10.Models
{
    public class AuthDbContext : DbContext
    {
        public AuthDbContext(DbContextOptions<AuthDbContext> options) : base(options) { }

        // Thêm DbSet cho các bảng
        public DbSet<User> Users { get; set; }
        public DbSet<ExpenseCategory> ExpenseCategories { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<EmailVerification> EmailVerifications { get; set; } // Thêm DbSet cho EmailVerification

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Thiết lập quan hệ giữa User và Transaction
            modelBuilder.Entity<Transaction>()
                .HasOne(t => t.User) // Một Transaction thuộc về một User
                .WithMany(u => u.Transactions) // Một User có nhiều Transactions
                .HasForeignKey(t => t.UserId); // Khóa ngoại là UserId

            // Thiết lập quan hệ giữa ExpenseCategory và Transaction
            modelBuilder.Entity<Transaction>()
                .HasOne(t => t.ExpenseCategory) // Một Transaction thuộc về một ExpenseCategory
                .WithMany(ec => ec.Transactions) // Một ExpenseCategory có nhiều Transactions
                .HasForeignKey(t => t.ExpenseCategoryId); // Khóa ngoại là ExpenseCategoryId

            // (Tùy chọn) Thiết lập ràng buộc hoặc chỉ mục nếu cần
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique(); // Đảm bảo Email là duy nhất

            modelBuilder.Entity<Transaction>()
                .Property(t => t.Amount)
                .HasColumnType("decimal(18, 2)"); // Định dạng số tiền

            // (Tùy chọn) Thiết lập giá trị mặc định cho trường Date trong Transaction
            modelBuilder.Entity<Transaction>()
                .Property(t => t.Date)
                .HasDefaultValueSql("GETDATE()"); // Mặc định là ngày hiện tại
        }
    }
}