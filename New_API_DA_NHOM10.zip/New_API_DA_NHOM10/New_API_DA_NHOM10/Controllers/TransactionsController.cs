﻿using Microsoft.AspNetCore.Mvc;
using New_API_DA_NHOM10.Models;
using NEW_API_DA_NHOM10.DTOs;
using NEW_API_DA_NHOM10.Models;
using NEW_API_DA_NHOM10.Repositories;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;

namespace NEW_API_DA_NHOM10.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionsController : ControllerBase
    {
        private readonly ITransactionRepository _transactionRepository;

        // Constructor: Tiêm ITransactionRepository vào controller
        public TransactionsController(ITransactionRepository transactionRepository)
        {
            _transactionRepository = transactionRepository;
        }
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetTransactionsByUserId(Guid userId)
        {
            var transactions = await _transactionRepository.GetTransactionsByUserIdAsync(userId);
            if (transactions == null || !transactions.Any())
            {
                return NotFound("No transactions found for this user.");
            }
            return Ok(transactions);
        }
        // GET: api/transactions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetTransactions()
        {
            var transactions = await _transactionRepository.GetAllTransactionsAsync();
            return Ok(transactions);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TransactionResponseDto>> GetTransaction(Guid id)
        {
            var transaction = await _transactionRepository.GetTransactionByIdAsync(id);
            if (transaction == null)
            {
                return NotFound();
            }

            // Tạo DTO để trả về
            var response = new TransactionResponseDto
            {
                Id = transaction.Id,
                UserId = transaction.UserId,
                ExpenseCategoryId = transaction.ExpenseCategoryId,
                Amount = transaction.Amount,
                Date = transaction.Date.ToString("dd/MM/yyyy"), // Định dạng lại ngày tháng
                Description = transaction.Description
            };

            return Ok(response);
        }

        [HttpPost]
        public async Task<ActionResult<Transaction>> AddTransaction([FromBody] AddTransactionDto addTransactionDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Chuyển đổi chuỗi dd/MM/yyyy sang DateTime
            DateTime transactionDate;
            bool isValidDate = DateTime.TryParseExact(
                addTransactionDto.Date, // Chuỗi đầu vào
                "dd/MM/yyyy",           // Định dạng mong muốn
                CultureInfo.InvariantCulture, // Sử dụng CultureInfo.InvariantCulture để tránh lỗi liên quan đến văn hóa
                DateTimeStyles.None,    // Không có style đặc biệt
                out transactionDate     // Kết quả chuyển đổi
            );

            // Kiểm tra nếu chuyển đổi không thành công
            if (!isValidDate)
            {
                ModelState.AddModelError("Date", "Invalid date format. Expected format: dd/MM/yyyy.");
                return BadRequest(ModelState);
            }

            // Tạo đối tượng Transaction từ DTO
            var transaction = new Transaction
            {
                UserId = addTransactionDto.UserId,
                ExpenseCategoryId = addTransactionDto.ExpenseCategoryId,
                Amount = addTransactionDto.Amount,
                Date = transactionDate, // Sử dụng giá trị DateTime đã chuyển đổi
                Description = addTransactionDto.Description
            };

            // Thêm giao dịch vào database
            await _transactionRepository.AddTransactionAsync(transaction);

            // Trả về kết quả thành công
            return CreatedAtAction(nameof(GetTransaction), new { id = transaction.Id }, transaction);
        }

        // PUT: api/transactions/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTransaction(Guid id, Transaction transaction)
        {
            if (id != transaction.Id)
            {
                return BadRequest();
            }

            await _transactionRepository.UpdateTransactionAsync(transaction);
            return NoContent();
        }

        // DELETE: api/transactions/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTransaction(Guid id)
        {
            await _transactionRepository.DeleteTransactionAsync(id);
            return NoContent();
        }
    }
}