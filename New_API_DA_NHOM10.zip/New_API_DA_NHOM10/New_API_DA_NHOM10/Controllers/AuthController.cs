﻿using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using New_API_DA_NHOM10.Models;
using NEW_API_DA_NHOM10.Models;
using Org.BouncyCastle.Crypto.Generators;
using test_api.Models;

namespace NEW_API_DA_NHOM10.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthDbContext _context;
        private const string DefaultAvatarUrl = "Uploads/default_avatar.jpg"; // Đường dẫn mặc định trong thư mục Uploads
        private readonly IConfiguration _configuration;
        private readonly EmailService _emailService;
        public AuthController(AuthDbContext context, IConfiguration configuration, EmailService emailService)
        {
            _context = context;
            _configuration = configuration;
            _emailService = emailService;
        }

        // **API Register**
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel request)
        {
            // Kiểm tra xem email đã tồn tại chưa
            if (_context.Users.Any(u => u.Email == request.Email))
            {
                return BadRequest("Email already exists.");
            }

            // Tạo user mới
            var user = new User
            {
                FullName = request.FullName,
                Email = request.Email,
                Password = request.Password // Mã hóa password
            };

            // Lưu user vào database
            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            // Tạo record xác thực email
            var emailVerification = new EmailVerification
            {
                UserId = user.Id, // Liên kết với user vừa tạo
                Token = Guid.NewGuid().ToString() // Tạo token ngẫu nhiên
            };

            _context.EmailVerifications.Add(emailVerification);
            await _context.SaveChangesAsync();

            // Tạo liên kết xác thực
            var verificationLink = Url.Action("VerifyEmail", "Auth", new { token = emailVerification.Token }, Request.Scheme);

            // Tạo nội dung email HTML
            var emailContent = $@"
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }}
        .container {{
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }}
        .token {{
            font-size: 18px;
            font-weight: bold;
            color: #007bff;
            margin: 20px 0;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
        }}
        .instructions {{
            font-size: 16px;
            color: #555;
        }}
    </style>
</head>
<body>
    <div class='container'>
        <h2>Xác Thực Email</h2>
        <p>Xin chào,</p>
        <p>Vui lòng sử dụng mã Token bên dưới để xác thực email của bạn:</p>
        <div class='token'>{emailVerification.Token}</div>
        <p class='instructions'>
            Để hoàn tất xác thực, hãy mở ứng dụng và nhập mã Token trên vào màn hình xác thực.
        </p>
        <p>Nếu bạn không yêu cầu xác thực này, vui lòng bỏ qua email này.</p>
    </div>
</body>
</html>";

            // Gửi email xác thực
            await _emailService.SendEmailAsync(user.Email, "Xác Thực Email", emailContent);

            return Ok(new
            {
                success = true,
                message = "User registered successfully. Please check your email to verify your account.",
                data = new
                {
                    user.Id,
                    user.FullName,
                    user.Email
                }
            });
        }



        [HttpGet("verify-email")]
        public async Task<IActionResult> VerifyEmail(string token)
        {
            // Tìm record xác thực email bằng token
            var emailVerification = await _context.EmailVerifications
                .Include(ev => ev.User)
                .FirstOrDefaultAsync(ev => ev.Token == token);

            if (emailVerification == null)
            {
                return BadRequest(new { success = false, message = "Invalid token." });
            }

            // Đánh dấu email đã được xác thực
            emailVerification.IsVerified = true;
            emailVerification.Token = null; // Xóa token sau khi xác thực
            await _context.SaveChangesAsync();

            // Trả về JSON với cấu trúc phù hợp
            return Ok(new
            {
                success = true,
                message = "Email verified successfully.",
                data = new
                {
                    emailVerification.UserId,
                    emailVerification.User.Email
                }
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new { success = false, message = "Invalid input" });
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Email == loginModel.Email && u.Password == loginModel.Password);

            if (user == null)
            {
                return Unauthorized(new { success = false, message = "Invalid email or password" });
            }

            // Trả về thông tin người dùng mà không bao gồm token và isVerified
            return Ok(new
            {
                success = true,
                message = "Logged in successfully",
                data = new
                {
                    
                    user.Id,
                    user.FullName,
                    user.Email,
                    user.AvatarUrl
                }
            });
        }


        [HttpPost("update-avatar")]
        public async Task<IActionResult> UpdateAvatar([FromBody] UpdateAvatarModel updateAvatarModel)
        {
            if (updateAvatarModel == null)
            {
                return BadRequest(new { Status = false, Message = "Request body is empty" });
            }

            try
            {
                // Validate input
                if (updateAvatarModel.UserId == Guid.Empty || string.IsNullOrEmpty(updateAvatarModel.AvatarUrl))
                {
                    return BadRequest(new { Status = false, Message = "Invalid input values" });
                }

                // Find user
                var user = await _context.Users.FindAsync(updateAvatarModel.UserId);
                if (user == null)
                {
                    return NotFound(new { Status = false, Message = "User not found" });
                }

                // Update avatar URL
                user.AvatarUrl = updateAvatarModel.AvatarUrl;
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = true,
                    Message = "Avatar updated successfully",
                    AvatarUrl = user.AvatarUrl
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Status = false, Message = "Internal server error", Error = ex.Message });
            }
        }

        [HttpPost("register-google")]
        public async Task<IActionResult> RegisterWithGoogle([FromBody] GoogleSignInModel model)
        {
            // Kiểm tra xem email đã tồn tại chưa
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.Email == model.Email);
            if (existingUser != null)
            {
                // Nếu email đã tồn tại, kiểm tra xem người dùng đã đăng ký bằng Google chưa
                if (existingUser.Password == model.GoogleId)
                {
                    // Nếu đúng, đăng nhập người dùng
                    var token = GenerateJwtToken(existingUser);
                    return Ok(new { Token = token, User = existingUser });
                }
                else
                {
                    // Nếu không, trả về lỗi (email đã được đăng ký bằng phương thức khác)
                    return BadRequest("Email already registered with a different method.");
                }
            }

            // Nếu email chưa tồn tại, tạo tài khoản mới
            var newUser = new User
            {
                Id = Guid.NewGuid(), // Tạo GUID mới
                FullName = model.FullName, // Lưu tên người dùng
                Email = model.Email,
                Password = model.GoogleId, // Lưu Google ID Token làm password
                AvatarUrl = model.AvatarUrl // Lưu URL ảnh đại diện
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            // Tạo token JWT
            var newToken = GenerateJwtToken(newUser);
            return Ok(new { Token = newToken, User = newUser });
        }

        private string GenerateJwtToken(User user)
        {
            // Lấy cấu hình JWT từ appsettings.json
            var jwtKey = _configuration.GetSection("JWTKey");
            var secret = jwtKey["Secret"];
            var issuer = jwtKey["ValidIssuer"];
            var audience = jwtKey["ValidAudience"];
            var expiryTimeInHour = int.Parse(jwtKey["TokenExpiryTimeInHour"]);

            // Tạo khóa bảo mật
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            // Tạo claims
            var claims = new[]
            {
        new Claim(JwtRegisteredClaimNames.Sub, user.Email),
        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
    };

            // Tạo token
            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.Now.AddHours(expiryTimeInHour), // Thời gian hết hạn
                signingCredentials: credentials
            );

            // Trả về token dưới dạng chuỗi
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
