﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using NEW_API_DA_NHOM10.Models;
using NEW_API_DA_NHOM10.Repositories;
using New_API_DA_NHOM10.Models;

namespace NEW_API_DA_NHOM10.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExpenseCategoryController : ControllerBase
    {
        private readonly IDefaultExpenseService _defaultExpenseService;
        private readonly IExpenseCategoryRepository _expenseCategoryRepository;

        public ExpenseCategoryController(
            IDefaultExpenseService defaultExpenseService,
            IExpenseCategoryRepository expenseCategoryRepository)
        {
            _defaultExpenseService = defaultExpenseService;
            _expenseCategoryRepository = expenseCategoryRepository;
        }

        // POST: api/ExpenseCategory/AddDefaultCategories/{userId}
        [HttpPost("AddDefaultCategories/{userId}")]
        public async Task<IActionResult> AddDefaultCategories(Guid userId)
        {
            try
            {
                await _defaultExpenseService.AddDefaultExpensesAsync(userId);
                return Ok("Các loại giao dịch mặc định đã được thêm thành công.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Đã xảy ra lỗi: {ex.Message}");
            }
        }

        // GET: api/ExpenseCategory/ByUser/{userId}
        [HttpGet("ByUser/{userId}")]
        public async Task<IActionResult> GetExpenseCategoriesByUser(Guid userId)
        {
            try
            {
                var expenseCategories = await _expenseCategoryRepository.GetExpenseCategoriesByUserIdAsync(userId);
                return Ok(expenseCategories);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Đã xảy ra lỗi: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddExpenseCategory([FromBody] ExpenseCategoryRequest request)
        {
            try
            {
                if (request == null)
                {
                    return BadRequest("Dữ liệu danh mục chi tiêu không hợp lệ.");
                }

                // Tạo đối tượng ExpenseCategory từ request
                var expenseCategory = new ExpenseCategory
                {
                    Name = request.Name,
                    Icon = request.Icon,
                    Type = request.Type,
                    UserId = request.UserId
                };

                // Thêm danh mục chi tiêu mới
                var addedCategory = await _expenseCategoryRepository.AddExpenseCategoryAsync(expenseCategory);

                // Trả về kết quả thành công
                return CreatedAtAction(nameof(GetExpenseCategoriesByUser), new { userId = addedCategory.UserId }, addedCategory);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Đã xảy ra lỗi: {ex.Message}");
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateExpenseCategory([FromBody] ExpenseCategoryRequest request)
        {
            try
            {
                if (request == null || request.Id == Guid.Empty)
                {
                    return BadRequest("Dữ liệu danh mục chi tiêu không hợp lệ.");
                }

                // Tìm danh mục chi tiêu cần cập nhật
                var existingExpenseCategory = await _expenseCategoryRepository.GetExpenseCategoryByIdAndUserIdAsync(request.Id, request.UserId);

                if (existingExpenseCategory == null)
                {
                    return NotFound("Không tìm thấy danh mục chi tiêu để cập nhật.");
                }

                // Cập nhật thông tin
                existingExpenseCategory.Name = request.Name;
                existingExpenseCategory.Icon = request.Icon;
                existingExpenseCategory.Type = request.Type;

                // Lưu thay đổi
                var updatedCategory = await _expenseCategoryRepository.UpdateExpenseCategoryAsync(existingExpenseCategory);

                // Trả về kết quả thành công
                return Ok(updatedCategory);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Đã xảy ra lỗi: {ex.Message}");
            }
        }
        // GET: api/ExpenseCategory/{id}/type-and-icon
        [HttpGet("{id}/type-and-icon")]
        public async Task<IActionResult> GetTypeAndIconByExpenseCategoryId(Guid id)
        {
            try
            {
                // Lấy thông tin ExpenseCategory từ repository
                var expenseCategory = await _expenseCategoryRepository.GetExpenseCategoryByIdAsync(id);

                if (expenseCategory == null)
                {
                    return NotFound("Không tìm thấy danh mục chi tiêu với ID đã cung cấp.");
                }

                // Trả về thông tin type và icon
                var response = new
                {
                    Type = expenseCategory.Type,
                    Icon = expenseCategory.Icon
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Đã xảy ra lỗi: {ex.Message}");
            }
        }
        [HttpDelete]
        public async Task<IActionResult> DeleteExpenseCategory([FromBody] DeleteExpenseCategoryRequest request)
        {
            try
            {
                if (request == null)
                {
                    return BadRequest("Dữ liệu danh mục chi tiêu không hợp lệ.");
                }

                // Xóa danh mục chi tiêu
                var isDeleted = await _expenseCategoryRepository.DeleteExpenseCategoryAsync(request.Id, request.UserId);

                if (!isDeleted)
                {
                    return NotFound("Không tìm thấy danh mục chi tiêu để xóa.");
                }

                // Trả về kết quả thành công
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Đã xảy ra lỗi: {ex.Message}");
            }
        }
    }
}