﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NEW_API_DA_NHOM10.Models;

namespace NEW_API_DA_NHOM10.Repositories
{
    public class DefaultExpenseService : IDefaultExpenseService
    {
        private readonly AuthDbContext _context;

        public DefaultExpenseService(AuthDbContext context)
        {
            _context = context;
        }

        public async Task AddDefaultExpensesAsync(Guid userId)
        {
            // Danh sách các loại giao dịch mặc định với mã Unicode của biểu tượng
            var defaultCategories = new List<ExpenseCategory>
            {
                new ExpenseCategory { Name = "Lương", Icon = "f555", Type = 1, UserId = userId }, // Biểu tượng "money-bill"
                new ExpenseCategory { Name = "Đầu tư", Icon = "f201", Type = 1, UserId = userId }, // Biểu tượng "chart-line"
                new ExpenseCategory { Name = "Tiết kiệm", Icon = "f4d3", Type = 1, UserId = userId }, // Biểu tượng "piggy-bank"
                new ExpenseCategory { Name = "Mua sắm", Icon = "f07a", Type = 2, UserId = userId }, // Biểu tượng "shopping-cart"
                new ExpenseCategory { Name = "Thuê nhà", Icon = "e1b0", Type = 2, UserId = userId }, // Biểu tượng "house-user"
                new ExpenseCategory { Name = "Ăn uống", Icon = "f2e7", Type = 2, UserId = userId }, // Biểu tượng "utensils"
                new ExpenseCategory { Name = "Trả nợ", Icon = "f555", Type = 2, UserId = userId }, // Biểu tượng "hand-holding-usd"
                new ExpenseCategory { Name = "Chi tiêu khác", Icon = "f128", Type = 3, UserId = userId }, // Biểu tượng "ellipsis-h"
                new ExpenseCategory { Name = "Quà tặng", Icon = "f06b", Type = 3, UserId = userId }, // Biểu tượng "gift"
                new ExpenseCategory { Name = "Học phí", Icon = "f19d", Type = 3, UserId = userId }, // Biểu tượng "graduation-cap"
                new ExpenseCategory { Name = "Y tế", Icon = "f21e", Type = 3, UserId = userId }, // Biểu tượng "briefcase-medical"
                new ExpenseCategory { Name = "Du lịch", Icon = "f072", Type = 3, UserId = userId } // Biểu tượng "plane"
            };

            // Thêm các loại giao dịch mặc định vào DbContext và lưu vào cơ sở dữ liệu
            await _context.ExpenseCategories.AddRangeAsync(defaultCategories);
            await _context.SaveChangesAsync();
        }
    }
}