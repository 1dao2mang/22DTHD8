﻿//namespace New_API_DA_NHOM10.Repositories
//{
//    public class IEmailService
//    {
//        Task SendEmailAsync(string email, string subject, string htmlMessage);
//    }
//}
