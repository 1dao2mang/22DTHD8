﻿using System;
using System.Threading.Tasks;

namespace NEW_API_DA_NHOM10.Repositories
{
    public interface IDefaultExpenseService
    {
        Task AddDefaultExpensesAsync(Guid userId); // Phương thức để thêm các giao dịch mặc định
    }
}