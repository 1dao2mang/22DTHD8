﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NEW_API_DA_NHOM10.Models;

namespace NEW_API_DA_NHOM10.Repositories
{
    public interface ITransactionRepository
    {
        // Lấy danh sách tất cả giao dịch
        Task<IEnumerable<Transaction>> GetAllTransactionsAsync();

        // Lấy giao dịch theo ID
        Task<Transaction> GetTransactionByIdAsync(Guid id);

        // Thêm giao dịch mới
        Task AddTransactionAsync(Transaction transaction);

        // Cập nhật giao dịch
        Task UpdateTransactionAsync(Transaction transaction);

        // Xóa giao dịchx
        Task DeleteTransactionAsync(Guid id);
        //Lấy giao dịch theo UserID
        Task<IEnumerable<Transaction>> GetTransactionsByUserIdAsync(Guid userId);
    }
}