﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NEW_API_DA_NHOM10.Models;

namespace NEW_API_DA_NHOM10.Repositories
{
    public class ExpenseCategoryRepository : IExpenseCategoryRepository
    {
        private readonly AuthDbContext _context;

        public ExpenseCategoryRepository(AuthDbContext context)
        {
            _context = context;
        }

        public async Task<List<ExpenseCategory>> GetExpenseCategoriesByUserIdAsync(Guid userId)
        {
            return await _context.ExpenseCategories
                .Where(ec => ec.UserId == userId)
                .ToListAsync();
        }

        public async Task<ExpenseCategory> AddExpenseCategoryAsync(ExpenseCategory expenseCategory)
        {
            if (expenseCategory == null)
            {
                throw new ArgumentNullException(nameof(expenseCategory));
            }

            _context.ExpenseCategories.Add(expenseCategory);
            await _context.SaveChangesAsync();
            return expenseCategory;
        }

        public async Task<ExpenseCategory> UpdateExpenseCategoryAsync(ExpenseCategory expenseCategory)
        {
            if (expenseCategory == null)
            {
                throw new ArgumentNullException(nameof(expenseCategory));
            }

            _context.ExpenseCategories.Update(expenseCategory);
            await _context.SaveChangesAsync();
            return expenseCategory;
        }

        public async Task<bool> DeleteExpenseCategoryAsync(Guid id, Guid userId)
        {
            var expenseCategory = await _context.ExpenseCategories
                .FirstOrDefaultAsync(ec => ec.Id == id && ec.UserId == userId);

            if (expenseCategory == null)
            {
                return false;
            }

            _context.ExpenseCategories.Remove(expenseCategory);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<ExpenseCategory> GetExpenseCategoryByIdAndUserIdAsync(Guid id, Guid userId)
        {
            return await _context.ExpenseCategories
                .FirstOrDefaultAsync(ec => ec.Id == id && ec.UserId == userId);
        }
        public async Task<ExpenseCategory> GetExpenseCategoryByIdAsync(Guid id)
        {
            return await _context.ExpenseCategories
                .FirstOrDefaultAsync(ec => ec.Id == id);
        }
    }
}