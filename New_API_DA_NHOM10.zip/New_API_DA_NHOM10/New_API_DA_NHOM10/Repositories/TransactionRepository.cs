﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NEW_API_DA_NHOM10.Models;

namespace NEW_API_DA_NHOM10.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly AuthDbContext _context;

        // Constructor: Tiêm DbContext vào repository
        public TransactionRepository(AuthDbContext context)
        {
            _context = context;
        }

        // Lấy danh sách tất cả giao dịch
        public async Task<IEnumerable<Transaction>> GetAllTransactionsAsync()
        {
            return await _context.Transactions.ToListAsync();
        }

        // Lấy giao dịch theo ID
        public async Task<Transaction> GetTransactionByIdAsync(Guid id)
        {
            return await _context.Transactions.FindAsync(id);
        }

        // Thêm giao dịch mới
        public async Task AddTransactionAsync(Transaction transaction)
        {
            await _context.Transactions.AddAsync(transaction);
            await _context.SaveChangesAsync();
        }

        // Cập nhật giao dịch
        public async Task UpdateTransactionAsync(Transaction transaction)
        {
            _context.Transactions.Update(transaction);
            await _context.SaveChangesAsync();
        }

        // Xóa giao dịch
        public async Task DeleteTransactionAsync(Guid id)
        {
            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction != null)
            {
                _context.Transactions.Remove(transaction);
                await _context.SaveChangesAsync();
            }
        }
        public async Task<IEnumerable<Transaction>> GetTransactionsByUserIdAsync(Guid userId)
        {
            return await _context.Transactions
                .Where(t => t.UserId == userId) // Lọc theo userId
                .ToListAsync();
        }
    }
}