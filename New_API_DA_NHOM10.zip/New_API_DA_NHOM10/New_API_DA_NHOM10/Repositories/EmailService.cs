﻿using MailKit.Net.Smtp; // Sử dụng MailKit
using MimeKit;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace test_api.Models
{
    public class EmailService
    {
        private readonly IConfiguration _configuration;

        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task SendEmailAsync(string recipientEmail, string subject, string htmlBody)
        {
            // Tạo email message
            var email = new MimeMessage();
            email.From.Add(new MailboxAddress(
                _configuration["SmtpSettings:SenderName"], // Tên người gửi
                _configuration["SmtpSettings:SenderEmail"] // Email người gửi
            ));
            email.To.Add(MailboxAddress.Parse(recipientEmail)); // Email người nhận
            email.Subject = subject; // Tiêu đề email

            // Tạo nội dung email dạng HTML
            email.Body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = htmlBody
            };

            // Gửi email sử dụng MailKit
            using var smtp = new SmtpClient(); // Sử dụng MailKit.Net.Smtp.SmtpClient
            try
            {
                // Kết nối đến SMTP server
                await smtp.ConnectAsync(
                    _configuration["SmtpSettings:Server"], // SMTP server
                    int.Parse(_configuration["SmtpSettings:Port"]), // Port
                    MailKit.Security.SecureSocketOptions.StartTls // Sử dụng StartTLS
                );

                // Xác thực với email và mật khẩu
                await smtp.AuthenticateAsync(
                    _configuration["SmtpSettings:SenderEmail"], // Email gửi
                    _configuration["SmtpSettings:SenderPassword"] // Mật khẩu
                );

                // Gửi email
                await smtp.SendAsync(email);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                throw new InvalidOperationException("Could not send email.", ex);
            }
            finally
            {
                // Ngắt kết nối
                await smtp.DisconnectAsync(true);
            }
        }
    }
}