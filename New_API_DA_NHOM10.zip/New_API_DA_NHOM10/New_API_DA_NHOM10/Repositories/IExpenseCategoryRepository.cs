﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NEW_API_DA_NHOM10.Models;

namespace NEW_API_DA_NHOM10.Repositories
{
    public interface IExpenseCategoryRepository
    {
        Task<List<ExpenseCategory>> GetExpenseCategoriesByUserIdAsync(Guid userId);
        Task<ExpenseCategory> AddExpenseCategoryAsync(ExpenseCategory expenseCategory);
        Task<ExpenseCategory> UpdateExpenseCategoryAsync(ExpenseCategory expenseCategory);
        Task<bool> DeleteExpenseCategoryAsync(Guid id, Guid userId);
        Task<ExpenseCategory> GetExpenseCategoryByIdAndUserIdAsync(Guid id, Guid userId);
        Task<ExpenseCategory> GetExpenseCategoryByIdAsync(Guid id);
    }
}